import { deleteUser, onAuthStateChanged } from "firebase/auth";
import { get, ref, remove, set } from "firebase/database";
import { createContext, useEffect, useState } from "react";
import { auth, db } from "../../firebase";

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  // Existing states...
  const [onlineBal, setOnlineBal] = useState(0);
  const [cashBal, setCashBal] = useState(0);
  const [transactions, setTransactions] = useState([]);
  const [onlineBudget, setOnlineBudget] = useState(0);
  const [cashBudget, setCashBudget] = useState(0);
  // Add these to your AppContext.js state
  const [manualGoal, setManualGoal] = useState(0);
  const [manualSaved, setManualSaved] = useState(0);
  const [dailyBaseline, setDailyBaseline] = useState(0); // Amount user intends to save daily

  // Budget Rollover State
  const [budgetRollover, setBudgetRollover] = useState({
    onlineRollover: 0,
    cashRollover: 0,
  });

  // Notification Preferences
  const [notificationSettings, setNotificationSettings] = useState({
    enableBudgetAlerts: true,
    enableWarningAt80: true,
    enableCriticalAt100: true,
    enableCategoryAlerts: true,
  });

  // ✅ NEW: Initialize goal values from localStorage on mount (web only)
  useEffect(() => {
    if (typeof localStorage === "undefined") return; // Skip on React Native
    
    const savedGoal = localStorage.getItem("manualGoal");
    const savedAmount = localStorage.getItem("manualSaved");
    const savedBaseline = localStorage.getItem("dailyBaseline");

    if (savedGoal) setManualGoal(parseFloat(savedGoal));
    if (savedAmount) setManualSaved(parseFloat(savedAmount));
    if (savedBaseline) setDailyBaseline(parseFloat(savedBaseline));
  }, []);

  // ✅ NEW: Initialize budget values from localStorage on mount (web only)
  useEffect(() => {
    if (typeof localStorage === "undefined") return; // Skip on React Native
    
    const savedOnlineBudget = localStorage.getItem("onlineBudget");
    const savedCashBudget = localStorage.getItem("cashBudget");

    if (savedOnlineBudget) setOnlineBudget(parseFloat(savedOnlineBudget));
    if (savedCashBudget) setCashBudget(parseFloat(savedCashBudget));
  }, []);

  // ✅ NEW: Save goal to localStorage whenever it changes (web only)
  useEffect(() => {
    if (typeof localStorage === "undefined") return; // Skip on React Native
    localStorage.setItem("manualGoal", manualGoal.toString());
  }, [manualGoal]);

  // ✅ NEW: Save manualSaved to localStorage whenever it changes (web only)
  useEffect(() => {
    if (typeof localStorage === "undefined") return; // Skip on React Native
    localStorage.setItem("manualSaved", manualSaved.toString());
  }, [manualSaved]);

  // ✅ NEW: Save dailyBaseline to localStorage whenever it changes (web only)
  useEffect(() => {
    if (typeof localStorage === "undefined") return; // Skip on React Native
    localStorage.setItem("dailyBaseline", dailyBaseline.toString());
  }, [dailyBaseline]);

  // ✅ NEW: Save onlineBudget to localStorage whenever it changes (web only)
  useEffect(() => {
    if (typeof localStorage === "undefined") return; // Skip on React Native
    localStorage.setItem("onlineBudget", onlineBudget.toString());
  }, [onlineBudget]);

  // ✅ NEW: Save cashBudget to localStorage whenever it changes (web only)
  useEffect(() => {
    if (typeof localStorage === "undefined") return; // Skip on React Native
    localStorage.setItem("cashBudget", cashBudget.toString());
  }, [cashBudget]);

  const saveGoalToCloud = async (goal, saved, baseline) => {
    console.log("🔥 Save function triggered");

    const user = auth.currentUser;

    if (!user) {
      console.log("❌ No authenticated user");
      return;
    }

    console.log("✅ User UID:", user.uid);

    try {
      await set(ref(db, `goals/${user.uid}`), {
        manualGoal: goal,
        manualSaved: saved,
        dailyBaseline: baseline,
      });

      // ✅ Also save to localStorage as backup (web only)
      if (typeof localStorage !== "undefined") {
        localStorage.setItem("manualGoal", goal.toString());
        localStorage.setItem("manualSaved", saved.toString());
        localStorage.setItem("dailyBaseline", baseline.toString());
      }

      console.log("✅ Goal saved to Firebase and localStorage successfully");
    } catch (error) {
      console.log("❌ Firebase error:", error);
    }
  };

  // ✅ NEW: Save budget to both Firebase and localStorage (web only)
  const saveBudgetToCloud = async (online, cash) => {
    console.log("💰 Saving budget...");

    const user = auth.currentUser;

    if (!user) {
      console.log("❌ No authenticated user");
      return;
    }

    console.log("✅ User UID:", user.uid);

    try {
      await set(ref(db, `budgets/${user.uid}`), {
        onlineBudget: online,
        cashBudget: cash,
      });

      // ✅ Also save to localStorage as backup (web only)
      if (typeof localStorage !== "undefined") {
        localStorage.setItem("onlineBudget", online.toString());
        localStorage.setItem("cashBudget", cash.toString());
      }

      console.log("✅ Budget saved to Firebase and localStorage successfully");
    } catch (error) {
      console.log("❌ Firebase error:", error);
    }
  };

  // NEW: Manual Categories State - with Education and Travel as defaults and icons
  const [categories, setCategories] = useState([
    {
      id: "0",
      name: "Other",
      limit: 0,
      spent: 0,
      icon: "📌",
      color: "#9B59B6",
    },
    {
      id: "1",
      name: "Food",
      limit: 5000,
      spent: 0,
      icon: "🍔",
      color: "#FF6B6B",
    },
    {
      id: "2",
      name: "Rent",
      limit: 15000,
      spent: 0,
      icon: "🏠",
      color: "#4ECDC4",
    },
    {
      id: "3",
      name: "Education",
      limit: 3000,
      spent: 0,
      icon: "📚",
      color: "#45B7D1",
    },
    {
      id: "4",
      name: "Travel",
      limit: 4000,
      spent: 0,
      icon: "✈️",
      color: "#FFA07A",
    },
  ]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        // Force Firebase to grab the absolute latest profile data (fixes signup lag)
        await user.reload();

        console.log("Auth User:", user);
        console.log("DisplayName:", user.displayName);

        setProfile({
          username: user.displayName || user.email.split("@")[0] || "User", // FIXED: Now strictly matches your state
          email: user.email || "",
          avatar: null,
        });
      } else {
        setProfile({ username: "", email: "", avatar: null });
      }
    });

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (!user) return;

      const goalRef = ref(db, `goals/${user.uid}`);

      get(goalRef).then((snap) => {
        if (snap.exists()) {
          const data = snap.val();
          setManualGoal(data.manualGoal || 0);
          setManualSaved(data.manualSaved || 0);
          setDailyBaseline(data.dailyBaseline || 0);
        }
      });
    });

    return () => unsubscribe();
  }, []);

  // 🔥 Load categories from Firebase on authentication
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (!user) {
        // Reset to default categories if logged out
        setCategories([
          {
            id: "0",
            name: "Other",
            limit: 0,
            spent: 0,
            icon: "📌",
            color: "#9B59B6",
          },
          {
            id: "1",
            name: "Food",
            limit: 5000,
            spent: 0,
            icon: "🍔",
            color: "#FF6B6B",
          },
          {
            id: "2",
            name: "Rent",
            limit: 15000,
            spent: 0,
            icon: "🏠",
            color: "#4ECDC4",
          },
          {
            id: "3",
            name: "Education",
            limit: 3000,
            spent: 0,
            icon: "📚",
            color: "#45B7D1",
          },
          {
            id: "4",
            name: "Travel",
            limit: 4000,
            spent: 0,
            icon: "✈️",
            color: "#FFA07A",
          },
        ]);
        return;
      }

      const categoriesRef = ref(db, `categories/${user.uid}`);

      get(categoriesRef).then((snap) => {
        if (snap.exists()) {
          const loadedCategories = snap.val();
          setCategories(loadedCategories);
          console.log("✅ Categories loaded from Firebase");
        }
      });
    });

    return () => unsubscribe();
  }, []);

  // 🔥 Recalculate category spent whenever transactions change
  useEffect(() => {
    setCategories((prevCats) =>
      prevCats.map((cat) => {
        const totalSpent = transactions
          .filter((txn) => txn.type === "expense" && txn.category === cat.id)
          .reduce((sum, txn) => sum + (parseFloat(txn.amount) || 0), 0);

        return { ...cat, spent: totalSpent };
      }),
    );
  }, [transactions]);

  // 🔥 Recalculate balances whenever transactions change
  useEffect(() => {
    let online = onlineBudget;
    let cash = cashBudget;

    transactions.forEach((txn) => {
      const amt = parseFloat(txn.amount) || 0;

      if (txn.type === "expense") {
        if (txn.mode === "online") online -= amt;
        else if (txn.mode === "cash") cash -= amt;
      } else if (txn.type === "income") {
        if (txn.mode === "online") online += amt;
        else if (txn.mode === "cash") cash += amt;
      }
    });

    // 🔒 Ensure balances never go negative
    setOnlineBal(Math.max(0, online));
    setCashBal(Math.max(0, cash));
  }, [transactions, onlineBudget, cashBudget]);

  const addCategory = (name, limit, color) => {
    const colors = [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A",
      "#98D8C8",
      "#F7DC6F",
      "#667BC6",
      "#E77F67",
      "#A0522D",
      "#20B2AA",
      "#DC143C",
      "#FFD700",
      "#9370DB",
      "#FF4500",
      "#00CED1",
      "#32CD32",
    ];
    const categoryColor =
      color || colors[Math.floor(Math.random() * colors.length)];
    const newCat = {
      id: Date.now().toString(),
      name,
      limit: parseFloat(limit),
      spent: 0,
      icon: "💰", // Default icon for new categories
      color: categoryColor,
    };
    setCategories((prev) => {
      const updated = [...prev, newCat];
      // 🔥 Persist to Firebase
      const user = auth.currentUser;
      if (user) {
        set(ref(db, `categories/${user.uid}`), updated).catch((err) =>
          console.error("❌ Error saving category:", err),
        );
      }
      return updated;
    });
  };

  const updateCategorySpend = (id, amt) => {
    const parsed = parseFloat(amt) || 0;
    setCategories((prev) =>
      prev.map((cat) =>
        cat.id === id ? { ...cat, spent: cat.spent + parsed } : cat,
      ),
    );
    const cat = categories.find((c) => c.id === id);
    const title = cat ? `Manual spend: ${cat.name}` : `Manual spend`;
    const txn = {
      id: Date.now().toString(),
      title,
      amount: parsed,
      mode: "online",
      type: "expense",
      category: id,
      date: new Date().toISOString(),
    };

    setTransactions((prev) => [...prev, txn]);
  };

  const updateCategory = (id, { name, limit }) => {
    setCategories((prev) => {
      const updated = prev.map((c) =>
        c.id === id ? { ...c, name, limit: parseFloat(limit) } : c,
      );
      // 🔥 Persist to Firebase
      const user = auth.currentUser;
      if (user) {
        set(ref(db, `categories/${user.uid}`), updated).catch((err) =>
          console.error("❌ Error updating category:", err),
        );
      }
      return updated;
    });
  };

  const updateCategoryColor = (id, color) => {
    setCategories((prev) => {
      const updated = prev.map((c) => (c.id === id ? { ...c, color } : c));
      // 🔥 Persist to Firebase
      const user = auth.currentUser;
      if (user) {
        set(ref(db, `categories/${user.uid}`), updated).catch((err) =>
          console.error("❌ Error updating category color:", err),
        );
      }
      return updated;
    });
  };

  const deleteCategory = (id) => {
    setCategories((prevCats) => {
      const newCats = prevCats.filter((c) => c.id !== id);
      return newCats;
    });

    const cat = categories.find((c) => c.id === id);
    return { deletedCat: cat, txnId: Date.now().toString() };
  };

  const undoDeleteCategory = (deletedCat, txnId) => {
    if (!deletedCat) return;
    setCategories((prev) => [...prev, deletedCat]);
    setTransactions((prev) => prev.filter((t) => t.id !== txnId));
  };

  const addTransaction = ({
    title,
    amount,
    mode = "online",
    type = "expense",
    category = null,
    date = null,
  }) => {
    const amt = parseFloat(amount) || 0;
    const txn = {
      id:
        arguments[0]?.id ||
        `${Date.now()}-${Math.floor(Math.random() * 1000000)}`,
      title,
      amount: amt,
      mode,
      type,
      category,
      date: date || new Date().toISOString(),
    };
    setTransactions((prev) => [...prev, txn]);
  };

  const editTransaction = (id, updates) => {
    setTransactions((prev) => {
      return prev.map((txn) => {
        if (txn.id !== id) return txn;

        const oldAmount = parseFloat(txn.amount) || 0;
        const newAmount = parseFloat(updates.amount) || oldAmount;

        const oldType = txn.type;
        const newType = updates.type || txn.type;

        const oldMode = txn.mode;
        const newMode = updates.mode || txn.mode;

        const oldCategory = txn.category;
        const newCategory =
          updates.category !== undefined ? updates.category : txn.category;

        // 🟢 Return updated transaction
        return {
          ...txn,
          ...updates,
          amount: newAmount,
          mode: newMode,
          type: newType,
          category: newCategory,
        };
      });
    });

    // 🔥 Save edited transaction to Firebase
    updateTransactionInCloud(id, updates);
  };

  const updateTransactionInCloud = async (id, updates) => {
    const user = auth.currentUser;
    if (!user) return;

    try {
      // Get the transaction from the current transactions to find the monthKey
      const txn = transactions.find((t) => t.id === id);
      if (!txn) return;

      const txnDate = new Date(txn.date || new Date());
      const monthKey = `${txnDate.getFullYear()}-${txnDate.getMonth() + 1}`;

      // Update in Firebase
      await set(ref(db, `expenses/${user.uid}/${monthKey}/${id}`), {
        ...txn,
        ...updates,
      });
      console.log("✅ Transaction updated in Firebase");
    } catch (error) {
      console.error("❌ Error updating transaction:", error);
    }
  };

  const deleteTransaction = (id) => {
    // Get transaction before removing to find monthKey
    const txnToDelete = transactions.find((t) => t.id === id);

    // Remove locally
    setTransactions((prev) => prev.filter((txn) => txn.id !== id));

    // Remove from Firebase
    const user = auth.currentUser;
    if (!user) return;

    if (txnToDelete) {
      const txnDate = new Date(txnToDelete.date || new Date());
      const monthKey = `${txnDate.getFullYear()}-${txnDate.getMonth() + 1}`;
      remove(ref(db, `expenses/${user.uid}/${monthKey}/${id}`));
    }
  };

  // Auth and profile state
  const [isAuth, setIsAuth] = useState(false);
  const [profile, setProfile] = useState({
    username: "",
    email: "",
    avatar: null,
  });

  const logout = () => setIsAuth(false);

  // Proper account deletion with Firebase cleanup
  const deleteAccount = async () => {
    console.log("🔴 deleteAccount called");
    const user = auth.currentUser;

    if (!user) {
      console.error("❌ No user logged in - auth.currentUser is", user);
      throw new Error("No user logged in");
    }

    console.log("✅ Found user:", user.email);

    try {
      // 1. Delete all user data from Firebase Database
      console.log("🔴 Deleting expenses...");
      await remove(ref(db, `expenses/${user.uid}`));
      console.log("✅ Expenses deleted");

      console.log("🔴 Deleting categories...");
      await remove(ref(db, `categories/${user.uid}`));
      console.log("✅ Categories deleted");

      console.log("🔴 Deleting goals...");
      await remove(ref(db, `goals/${user.uid}`));
      console.log("✅ Goals deleted");

      console.log("🔴 Deleting budgets...");
      await remove(ref(db, `budgets/${user.uid}`));
      console.log("✅ Budgets deleted");

      console.log("✅ All user data deleted from database");

      // 2. Delete user account from Firebase Auth
      console.log("🔴 Deleting auth user...");
      await deleteUser(user);
      console.log("✅ User account deleted from Firebase Auth");

      // 3. Clear localStorage (web only)
      console.log("🔴 Clearing localStorage...");
      if (typeof localStorage !== "undefined") {
        localStorage.removeItem("manualGoal");
        localStorage.removeItem("manualSaved");
        localStorage.removeItem("dailyBaseline");
        localStorage.removeItem("onlineBudget");
        localStorage.removeItem("cashBudget");
      }
      console.log("✅ localStorage cleared");

      // 4. Clear local state
      console.log("🔴 Clearing app state...");
      setCategories([]);
      setTransactions([]);
      setOnlineBal(0);
      setCashBal(0);
      setProfile({ username: "", email: "", avatar: null });
      setIsAuth(false);
      console.log("✅ App state cleared");

      // Function returns successfully - caller handles UI feedback
      console.log("✅✅✅ Account deletion complete");
    } catch (error) {
      console.error("❌❌❌ CRITICAL ERROR IN deleteAccount:", error);
      console.error("Error code:", error.code);
      console.error("Error message:", error.message);
      console.error("Full error object:", error);
      throw error; // Re-throw for caller to handle
    }
  };

  return (
    <AppContext.Provider
      value={{
        onlineBal,
        setOnlineBal,
        cashBal,
        setCashBal,
        onlineBudget,
        setOnlineBudget,
        cashBudget,
        setCashBudget,
        manualGoal,
        setManualGoal,
        manualSaved,
        setManualSaved,
        dailyBaseline,
        setDailyBaseline,
        categories,
        addCategory,
        updateCategorySpend,
        updateCategory,
        updateCategoryColor,
        deleteCategory,
        undoDeleteCategory,
        addTransaction,
        editTransaction,
        deleteTransaction,
        transactions,
        isAuth,
        setIsAuth,
        profile,
        setProfile,
        logout,
        deleteAccount,
        setTransactions,
        // ...existing code...
        budgetRollover,
        setBudgetRollover,
        notificationSettings,
        setNotificationSettings,
        saveGoalToCloud,
        saveBudgetToCloud,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
