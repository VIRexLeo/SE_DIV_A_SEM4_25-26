import { Ionicons } from "@expo/vector-icons";
import { useContext, useMemo } from "react";
import { Dimensions, ScrollView, StyleSheet, Text, View } from "react-native";
import { PieChart } from "react-native-chart-kit";
import { AppContext } from "../context/AppContext";

export default function CategoryInsightsScreen() {
  const { transactions, categories } = useContext(AppContext);

  // Get current month and previous month
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
  const lastYear = currentMonth === 0 ? currentYear - 1 : currentYear;

  // Calculate spending by category (current month)
  const categorySpending = useMemo(() => {
    const data = {};
    categories.forEach((cat) => {
      data[cat.id] = {
        name: cat.name,
        icon: cat.icon,
        amount: 0,
        limit: cat.limit,
      };
    });

    transactions.forEach((txn) => {
      const txnDate = new Date(txn.date);
      if (
        txn.type === "expense" &&
        txn.category &&
        txnDate.getMonth() === currentMonth &&
        txnDate.getFullYear() === currentYear
      ) {
        if (data[txn.category]) {
          data[txn.category].amount += parseFloat(txn.amount);
        }
      }
    });

    return Object.values(data).filter((item) => item.amount > 0);
  }, [transactions, categories, currentMonth, currentYear]);

  // Previous month comparison
  const lastMonthSpending = useMemo(() => {
    const data = {};
    categories.forEach((cat) => {
      data[cat.id] = 0;
    });

    transactions.forEach((txn) => {
      const txnDate = new Date(txn.date);
      if (
        txn.type === "expense" &&
        txn.category &&
        txnDate.getMonth() === lastMonth &&
        txnDate.getFullYear() === lastYear
      ) {
        if (data[txn.category] !== undefined) {
          data[txn.category] += parseFloat(txn.amount);
        }
      }
    });

    return data;
  }, [transactions, categories, lastMonth, lastYear]);

  // Total spending
  const currentMonthTotal = categorySpending.reduce(
    (sum, cat) => sum + cat.amount,
    0,
  );
  const lastMonthTotal = Object.values(lastMonthSpending).reduce(
    (sum, amt) => sum + amt,
    0,
  );
  const monthlyChange =
    lastMonthTotal > 0
      ? (((currentMonthTotal - lastMonthTotal) / lastMonthTotal) * 100).toFixed(
          1,
        )
      : 0;

  // Prepare pie chart data
  const pieData = categorySpending.map((cat, index) => ({
    name: `${cat.name}`,
    amount: cat.amount,
    color: getColorForIndex(index),
    legendFontColor: "#667085",
    legendFontSize: 12,
  }));

  function getColorForIndex(index) {
    const colors = [
      "#FF6B6B",
      "#4ECDC4",
      "#45B7D1",
      "#FFA07A",
      "#98D8C8",
      "#F7DC6F",
    ];
    return colors[index % colors.length];
  }

  const screenWidth = Dimensions.get("window").width;

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.scrollContent}
      showsVerticalScrollIndicator={true} // Set this to true to force the web scrollbar to appear
      bounces={true}
    >
      <Text style={styles.header}>Category Insights</Text>

      {/* Monthly Comparison */}
      <View style={styles.comparisonCard}>
        <View style={styles.comparisonRow}>
          <View>
            <Text style={styles.comparisonLabel}>This Month</Text>
            <Text style={styles.comparisonAmount}>
              ₹{currentMonthTotal.toFixed(0)}
            </Text>
          </View>
          <View style={styles.comparisonDivider} />
          <View style={{ alignItems: "flex-end" }}>
            <Text style={styles.comparisonLabel}>Last Month</Text>
            <Text style={styles.comparisonAmount}>
              ₹{lastMonthTotal.toFixed(0)}
            </Text>
          </View>
        </View>
        <View
          style={[
            styles.changeIndicator,
            monthlyChange > 0 ? styles.changeIncreased : styles.changeDecreased,
          ]}
        >
          <Ionicons
            name={monthlyChange > 0 ? "arrow-up" : "arrow-down"}
            size={16}
            color={monthlyChange > 0 ? "#EF4444" : "#10B981"}
          />
          <Text
            style={[
              styles.changeText,
              { color: monthlyChange > 0 ? "#EF4444" : "#10B981" },
            ]}
          >
            {Math.abs(monthlyChange)}%{" "}
            {monthlyChange > 0 ? "increase" : "decrease"}
          </Text>
        </View>
      </View>

      {/* Pie Chart */}
      {pieData.length > 0 ? (
        <View style={styles.chartContainer}>
          <Text style={styles.sectionTitle}>Spending Distribution</Text>
          <PieChart
            data={pieData}
            width={screenWidth - 40}
            height={250}
            chartConfig={{
              backgroundColor: "#FFF",
              color: (opacity = 1) => `rgba(101, 112, 133, ${opacity})`,
            }}
            accessor="amount"
            backgroundColor="transparent"
            paddingLeft="15"
          />
        </View>
      ) : (
        <View style={styles.emptyState}>
          <Ionicons name="pie-chart-outline" size={50} color="#D0D5DD" />
          <Text style={styles.emptyText}>No spending data this month.</Text>
        </View>
      )}

      {/* Detailed Breakdown */}
      <View style={styles.breakdownContainer}>
        <Text style={styles.sectionTitle}>Category Breakdown</Text>
        {categorySpending.length > 0 ? (
          categorySpending.map((cat, index) => {
            const percentage = ((cat.amount / currentMonthTotal) * 100).toFixed(
              1,
            );
            return (
              <View key={cat.name} style={styles.breakdownItem}>
                <View style={{ flex: 1 }}>
                  <View style={styles.categoryHeader}>
                    <Text style={styles.categoryName}>{cat.name}</Text>
                    <Text style={styles.categoryAmount}>
                      ₹{cat.amount.toFixed(0)}
                    </Text>
                  </View>
                  <View style={styles.progressBar}>
                    <View
                      style={[
                        styles.progressFill,
                        {
                          width: `${Math.min(percentage, 100)}%`,
                          backgroundColor: getColorForIndex(index),
                        },
                      ]}
                    />
                  </View>
                  <View style={styles.categoryMeta}>
                    <Text style={styles.categoryPercent}>
                      {percentage}% of total
                    </Text>
                    <Text style={styles.categoryLimit}>
                      Limit: ₹{cat.limit.toFixed(0)}
                    </Text>
                  </View>
                </View>
              </View>
            );
          })
        ) : (
          <Text style={styles.emptyText}>
            No categories with spending this month.
          </Text>
        )}
      </View>

      {/* Budget Status Summary */}
      <View style={styles.summaryContainer}>
        <Text style={styles.sectionTitle}>Budget Status</Text>
        {categories.map((cat) => {
          // 1. Get spent amount and limit as actual numbers
          const spent =
            categorySpending.find((c) => c.name === cat.name)?.amount || 0;
          const limit = parseFloat(cat.limit) || 0;

          let status = "On Track";
          let statusColor = "#10B981"; // Green

          // 2. Add progressive logic checks
          if (limit === 0) {
            status = "No Limit Set";
            statusColor = "#667085"; // Gray
          } else {
            const percentage = (spent / limit) * 100;

            if (percentage >= 100) {
              status = "Over Budget";
              statusColor = "#EF4444"; // Red
            } else if (percentage >= 80) {
              status = "Nearing Limit";
              statusColor = "#F59E0B"; // Orange
            }
          }

          return (
            <View key={cat.id} style={styles.budgetStatusItem}>
              <View style={{ flex: 1 }}>
                <Text style={styles.budgetName}>{cat.name}</Text>
                <Text style={styles.budgetProgress}>
                  ₹{spent.toFixed(0)} / ₹{limit.toFixed(0)}
                </Text>
              </View>
              <View
                style={[
                  styles.statusBadge,
                  { backgroundColor: `${statusColor}20` },
                ]}
              >
                <Text style={[styles.statusText, { color: statusColor }]}>
                  {status}
                </Text>
              </View>
            </View>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1, // This tells the outer box to fill the screen
    backgroundColor: "#FFF",
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 150, // Massive padding for web to ensure nothing gets cut off by bottom tabs
    flexGrow: 1, // <--- THIS IS THE MAGIC FIX FOR WEB SCROLLING
  },
  header: {
    fontSize: 24,
    // ... rest of your styles stay exactly the same
    fontWeight: "bold",
    marginTop: 40,
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#101828",
    marginBottom: 12,
  },
  comparisonCard: {
    backgroundColor: "#F9FAFB",
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: "#EAECF0",
  },
  comparisonRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  comparisonLabel: {
    fontSize: 12,
    color: "#667085",
    fontWeight: "500",
  },
  comparisonAmount: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#101828",
    marginTop: 4,
  },
  comparisonDivider: {
    width: 1,
    height: 50,
    backgroundColor: "#EAECF0",
  },
  changeIndicator: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  changeIncreased: {
    backgroundColor: "#FEF3F2",
  },
  changeDecreased: {
    backgroundColor: "#ECFDF3",
  },
  changeText: {
    marginLeft: 6,
    fontSize: 12,
    fontWeight: "600",
  },
  chartContainer: {
    backgroundColor: "#F9FAFB",
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: "#EAECF0",
    alignItems: "center",
  },
  breakdownContainer: {
    marginBottom: 24,
  },
  breakdownItem: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#F2F4F7",
  },
  categoryHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 8,
  },
  categoryName: {
    fontSize: 14,
    fontWeight: "600",
    color: "#101828",
  },
  categoryAmount: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#101828",
  },
  progressBar: {
    height: 8,
    backgroundColor: "#EAECF0",
    borderRadius: 4,
    overflow: "hidden",
    marginBottom: 8,
  },
  progressFill: {
    height: "100%",
    borderRadius: 4,
  },
  categoryMeta: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  categoryPercent: {
    fontSize: 11,
    color: "#667085",
  },
  categoryLimit: {
    fontSize: 11,
    color: "#667085",
  },
  summaryContainer: {
    marginBottom: 40,
  },
  budgetStatusItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#F2F4F7",
  },
  budgetName: {
    fontSize: 14,
    fontWeight: "600",
    color: "#101828",
  },
  budgetProgress: {
    fontSize: 12,
    color: "#667085",
    marginTop: 4,
  },
  statusBadge: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 6,
  },
  statusText: {
    fontSize: 11,
    fontWeight: "600",
  },
  emptyState: {
    justifyContent: "center",
    alignItems: "center",
    paddingVertical: 40,
  },
  emptyText: {
    color: "#98A2B3",
    marginTop: 10,
    textAlign: "center",
  },
});
