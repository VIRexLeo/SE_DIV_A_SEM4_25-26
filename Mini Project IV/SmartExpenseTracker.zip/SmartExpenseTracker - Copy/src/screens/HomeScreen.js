import { Ionicons } from "@expo/vector-icons";
import { get, onValue, push, ref, set } from "firebase/database";
import { useContext, useEffect, useMemo, useState } from "react";
import {
  Alert,
  Dimensions,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { BarChart, LineChart } from "react-native-chart-kit";
import Svg, { Circle, G } from "react-native-svg";
import { auth, db } from "../../firebase";
import { AppContext } from "../context/AppContext";

export default function HomeScreen({ navigation }) {
  const {
    onlineBal,
    setOnlineBal,
    cashBal,
    setCashBal,
    onlineBudget,
    setOnlineBudget,
    cashBudget,
    setCashBudget,
    setTransactions,
    transactions,
    categories,
    // ...existing code...
    notificationSettings,
    saveBudgetToCloud,
  } = useContext(AppContext);

  const [txnModal, setTxnModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState(null); // Will be set to Other by default
  const [monthlySummaryExpanded, setMonthlySummaryExpanded] = useState(false);
  const [lastOnlineAlert, setLastOnlineAlert] = useState(null);
  const [lastCashAlert, setLastCashAlert] = useState(null);

  // Transaction State
  const [amt, setAmt] = useState("");
  const [title, setTitle] = useState("");
  const [mode, setMode] = useState("online");
  const [cloudTxns, setCloudTxns] = useState([]);

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const monthKey = `${new Date().getFullYear()}-${new Date().getMonth() + 1}`;
    const txnRef = ref(db, `expenses/${user.uid}/${monthKey}`);

    const budgetRef = ref(db, `budgets/${user.uid}`);

    onValue(budgetRef, async (snap) => {
      if (!snap.exists()) return;

      const data = snap.val();
      const loadedOnlineBudget = data.onlineBudget || 0;
      const loadedCashBudget = data.cashBudget || 0;

      setOnlineBudget(loadedOnlineBudget);
      setCashBudget(loadedCashBudget);

      // 🔥 SAFE ROLLOVER CHECK
      const now = new Date();
      const currentMonth = `${now.getFullYear()}-${now.getMonth() + 1}`;
      const lastMonthRef = ref(db, `lastActiveMonth/${user.uid}`);

      const lastMonthSnap = await get(lastMonthRef);
      const lastMonth = lastMonthSnap.val();

      if (!lastMonth) {
        await set(lastMonthRef, currentMonth);
        return;
      }

      if (lastMonth !== currentMonth) {
        // Calculate rollover using CURRENT BALANCES
        const rolloverOnline = onlineBal;
        const rolloverCash = cashBal;

        const newOnlineBudget = loadedOnlineBudget + rolloverOnline;
        const newCashBudget = loadedCashBudget + rolloverCash;

        await set(ref(db, `budgets/${user.uid}`), {
          onlineBudget: newOnlineBudget,
          cashBudget: newCashBudget,
        });

        await set(lastMonthRef, currentMonth);
      }
    });

    onValue(txnRef, (snap) => {
      if (snap.exists()) {
        const data = snap.val();

        const list = Object.entries(data).map(([id, val]) => ({
          id,
          ...val,
        }));

        setTransactions(list);
      } else {
        setTransactions([]);
      }
    });
  }, []);

  // Calculate Spendings per mode
  const getSpent = (m) =>
    transactions
      .filter((t) => t.mode === m && t.type === "expense")
      .reduce((s, c) => s + parseFloat(c.amount), 0);

  const onlineSpent = getSpent("online");
  const cashSpent = getSpent("cash");
  const totalSpent = onlineSpent + cashSpent;
  const totalBudget = onlineBudget + cashBudget;

  // Budget alert logic
  const getOnlineAlert = () => {
    if (onlineBudget === 0) return null;
    const percentage = (onlineSpent / onlineBudget) * 100;
    if (percentage >= 100) return { level: "critical", percentage };
    if (percentage >= 80) return { level: "warning", percentage };
    return null;
  };

  const getCashAlert = () => {
    if (cashBudget === 0) return null;
    const percentage = (cashSpent / cashBudget) * 100;
    if (percentage >= 100) return { level: "critical", percentage };
    if (percentage >= 80) return { level: "warning", percentage };
    return null;
  };

  const onlineAlert = getOnlineAlert();
  const cashAlert = getCashAlert();
  // Trigger active popups when budget limits are breached
  useEffect(() => {
    // If the user turned off budget alerts in settings, do nothing. (Defaults to true)
    const alertsEnabled = notificationSettings?.budgetAlerts ?? true;
    if (!alertsEnabled) return;

    // Handle Online Budget Popups
    if (onlineAlert && onlineAlert.level !== lastOnlineAlert) {
      const msg =
        onlineAlert.level === "critical"
          ? "🚨 Critical: Online Budget exceeded 100%!"
          : "⚠️ Warning: Online Budget has reached 80%!";

      if (Platform.OS === "web") {
        window.alert(msg);
      } else {
        Alert.alert("Budget Alert", msg);
      }
      setLastOnlineAlert(onlineAlert.level);
    }

    // Handle Cash Budget Popups
    if (cashAlert && cashAlert.level !== lastCashAlert) {
      const msg =
        cashAlert.level === "critical"
          ? "🚨 Critical: Cash Budget exceeded 100%!"
          : "⚠️ Warning: Cash Budget has reached 80%!";

      if (Platform.OS === "web") {
        window.alert(msg);
      } else {
        Alert.alert("Budget Alert", msg);
      }
      setLastCashAlert(cashAlert.level);
    }
  }, [
    onlineAlert,
    cashAlert,
    notificationSettings,
    lastOnlineAlert,
    lastCashAlert,
  ]);

  // Calculate spending health score (0-100) - UPDATED LOGIC HERE
  const spendingHealth = useMemo(() => {
    if (totalBudget === 0) return 100;

    const today = new Date().getDate();
    const daysInMonth = new Date(
      new Date().getFullYear(),
      new Date().getMonth() + 1,
      0,
    ).getDate();

    const timeElapsedRatio = today / daysInMonth; 
    const budgetUsedRatio = totalSpent / totalBudget; 

    if (budgetUsedRatio <= timeElapsedRatio) {
      return 100;
    }

    if (budgetUsedRatio >= 1) {
      return 0;
    }

    const overspendRatio = (budgetUsedRatio - timeElapsedRatio) / (1 - timeElapsedRatio);
    const healthScore = 100 - (overspendRatio * 100);

    return Math.max(0, Math.min(100, Math.round(healthScore)));
  }, [totalSpent, totalBudget]);

  // Get spending health color based on score
  const getHealthColor = () => {
    if (spendingHealth >= 70) return "#10B981"; // Green - Good
    if (spendingHealth >= 40) return "#F59E0B"; // Orange - Warning
    return "#EF4444"; // Red - Critical
  };

  // Generate daily spending data for the last 7 days (with proper optimization)
  const chartData = useMemo(() => {
    // 1. Calculate Daily Baseline Budget
    const totalBudget =
      (parseFloat(onlineBudget) || 0) + (parseFloat(cashBudget) || 0);
    const dailyBaseline = totalBudget > 0 ? totalBudget / 30 : 0;

    // 2. Setup arrays for the last 7 days
    const days = 7;
    const actualData = Array(days).fill(0);
    const labels = Array(days).fill("");
    const baselineData = Array(days).fill(dailyBaseline);

    // Normalize 'today' to exactly midnight to prevent timezone/hour shifting bugs
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Pre-fill X-axis labels (e.g., "Mon", "Tue") so the graph is always up to date
    for (let i = 0; i < days; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() - (days - 1 - i));
      labels[i] = d.toLocaleDateString("en-US", { weekday: "short" });
    }

    // 3. Aggregate your transactions
    transactions.forEach((txn) => {
      if (txn.type === "expense") {
        const txnDate = new Date(txn.date);
        txnDate.setHours(0, 0, 0, 0); // Normalize transaction to midnight

        // Calculate exact day difference
        const diffTime = today.getTime() - txnDate.getTime();
        const daysAgo = Math.floor(diffTime / (1000 * 60 * 60 * 24));

        // Map it to the correct index (0 is 6 days ago, 6 is today)
        if (daysAgo >= 0 && daysAgo < days) {
          const index = days - 1 - daysAgo;
          actualData[index] += parseFloat(txn.amount || 0);
        }
      }
    });

    // 4. Return data structured for react-native-chart-kit
    return {
      labels,
      datasets: [
        {
          data: actualData,
          color: (opacity = 1) => `rgba(239, 68, 68, ${opacity})`, // Red line for Actual
          strokeWidth: 3,
        },
        {
          data: baselineData,
          color: (opacity = 1) => `rgba(34, 197, 94, ${opacity})`, // Green line for Baseline
          strokeWidth: 2,
          withDots: false, // Hide dots on baseline to make it look like a limit line
        },
      ],
      legend: ["Actual Spend", "Daily Limit"],
    };
  }, [transactions, onlineBudget, cashBudget]); // ✅ FIXED: Proper dependency array

  // Calculate projected money left (improved zero date)
  const projectedDaysLeft = useMemo(() => {
    const today = new Date().getDate();

    if (today === 0) return 999;

    const avgDailySpending = totalSpent / today;

    if (avgDailySpending === 0) return 999;

    const totalMoneyLeft = onlineBal + cashBal;

    return Math.floor(totalMoneyLeft / avgDailySpending);
  }, [onlineBal, cashBal, totalSpent]);

  // Calculate monthly summary data (weekly breakdown)
  const monthlySummary = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();
    const monthlyByWeek = [0, 0, 0, 0];

    transactions.forEach((txn) => {
      if (txn.type === "expense") {
        const txnDate = new Date(txn.date || now);
        if (
          txnDate.getMonth() === currentMonth &&
          txnDate.getFullYear() === currentYear
        ) {
          const week = Math.min(3, Math.floor((txnDate.getDate() - 1) / 7));
          monthlyByWeek[week] += parseFloat(txn.amount);
        }
      }
    });

    return monthlyByWeek;
  }, [transactions]);

  const monthName = new Date().toLocaleString("en-IN", { month: "long" });
  const screenWidth = Dimensions.get("window").width;

  // Save transaction to Firebase
  const saveTxnToCloud = async (txn) => {
    const user = auth.currentUser;

    if (!user) return;
    const now = new Date();
    const currentMonth = `${now.getFullYear()}-${now.getMonth() + 1}`;

    const lastMonthRef = ref(db, `lastActiveMonth/${user.uid}`);

    get(lastMonthRef).then((snap) => {
      const lastMonth = snap.val();

      if (lastMonth && lastMonth !== currentMonth) {
        // Month changed

        const rolloverOnline = onlineBal;
        const rolloverCash = cashBal;

        const newOnlineBudget = onlineBudget + rolloverOnline;
        const newCashBudget = cashBudget + rolloverCash;

        set(ref(db, `budgets/${user.uid}`), {
          onlineBudget: newOnlineBudget,
          cashBudget: newCashBudget,
        });

        set(ref(db, `lastActiveMonth/${user.uid}`), currentMonth);
      }

      if (!lastMonth) {
        set(ref(db, `lastActiveMonth/${user.uid}`), currentMonth);
      }
    });

    const monthKey = `${new Date().getFullYear()}-${new Date().getMonth() + 1}`;

    await push(ref(db, `expenses/${user.uid}/${monthKey}`), {
      ...txn,
      date: new Date().toISOString(),
    });
  };

  return (
    <View style={[styles.container, { backgroundColor: "#FFFFFF" }]}>
      <ScrollView
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingTop: 0,
          paddingBottom: 100,
        }}
      >
        {/* Header with navigation buttons */}
        {/* Header with navigation buttons */}
        <View style={styles.header}>
          {/* 👇 CHANGE THIS LINE FROM "Settings" TO "Profile" */}
          <TouchableOpacity onPress={() => navigation.navigate("Profile")}>
            <Ionicons name="person-circle-outline" size={32} color="#101828" />
          </TouchableOpacity>
          <Text style={[styles.title, { color: "#101828" }]}>
            Smart Dashboard
          </Text>
          <View style={{ flexDirection: "row", gap: 8 }}>
            {/* ... other buttons stay the same ... */}
            <TouchableOpacity
              onPress={() => navigation.navigate("CategoryInsights")}
            >
              <Ionicons name="pie-chart-outline" size={28} color="#101828" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => navigation.navigate("Settings")}>
              <Ionicons name="settings-outline" size={28} color="#101828" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Dual Budget Progress Cards */}
        <View style={styles.budgetSection}>
          <BudgetCard
            label="Online Monthly Budget"
            spent={onlineSpent}
            total={onlineBudget}
            color="#667EEA"
          />
          <BudgetCard
            label="Cash Monthly Budget"
            spent={cashSpent}
            total={cashBudget}
            color="#F59E0B"
          />
        </View>

        {/* Current Balances (PPT Feature) */}
        <View style={styles.row}>
          <View style={[styles.balanceBox, { backgroundColor: "#667EEA" }]}>
            <Text style={styles.label}>Online Bal</Text>
            <Text style={styles.val}>₹{Math.round(onlineBal)}</Text>
          </View>
          <View style={[styles.balanceBox, { backgroundColor: "#F59E0B" }]}>
            <Text style={styles.label}>Cash Bal</Text>
            <Text style={styles.val}>₹{Math.round(cashBal)}</Text>
          </View>
        </View>

        {/* Monthly Summary Card */}
        <TouchableOpacity
          style={styles.monthlySummaryCard}
          onPress={() => setMonthlySummaryExpanded(!monthlySummaryExpanded)}
        >
          <Text style={styles.sectionTitle}>Monthly Analysis</Text>
          <View style={styles.monthlySummaryHeader}>
            <View>
              <Text style={styles.monthlySummaryLabel}>
                {monthName} Summary
              </Text>
              <Text style={styles.monthlySummaryAmount}>
                ₹{totalSpent.toFixed(0)}
              </Text>
            </View>
            <Ionicons
              name={monthlySummaryExpanded ? "chevron-up" : "chevron-down"}
              size={24}
              color="#667085"
            />
          </View>

          {!monthlySummaryExpanded && (
            <View style={styles.monthlySummaryPreview}>
              <View style={styles.previewItem}>
                <Text style={styles.previewLabel}>Budget Used</Text>
                <Text style={styles.previewValue}>
                  {totalBudget > 0
                    ? Math.round((totalSpent / totalBudget) * 100)
                    : 0}
                  %
                </Text>
              </View>
              <View style={styles.previewItem}>
                <Text style={styles.previewLabel}>Remaining</Text>
                <Text style={styles.previewValue}>
                  ₹{Math.max(0, totalBudget - totalSpent).toFixed(0)}
                </Text>
              </View>
              <View style={styles.previewItem}>
                <Text style={styles.previewLabel}>Categories</Text>
                <Text style={styles.previewValue}>{categories.length}</Text>
              </View>
            </View>
          )}

          {monthlySummaryExpanded && (
            <View style={styles.monthlySummaryChart}>
              <Text style={styles.chartSubtitle}>Weekly Breakdown</Text>
              <BarChart
                data={{
                  labels: ["W1", "W2", "W3", "W4"],
                  datasets: [
                    {
                      data: monthlySummary.map((val) => val || 0),
                    },
                  ],
                }}
                width={screenWidth - 30}
                height={220}
                chartConfig={{
                  backgroundColor: "#F8F9FF",
                  backgroundGradientFrom: "#F8F9FF",
                  backgroundGradientTo: "#F8F9FF",
                  color: (opacity = 1) => `rgba(102, 126, 234, ${opacity})`,
                  labelColor: (opacity = 1) =>
                    `rgba(107, 114, 128, ${opacity})`,
                  style: { borderRadius: 12 },
                  barPercentage: 0.6,
                }}
                style={{ borderRadius: 12 }}
              />

              {/* Monthly Insights */}
              <View style={styles.monthlyInsights}>
                <View style={styles.insightItem}>
                  <Text style={styles.insightLabel}>Daily Average</Text>
                  <Text style={styles.insightValue}>
                    ₹{(totalSpent / 30).toFixed(0)}
                  </Text>
                </View>
                <View style={styles.insightDivider} />
                <View style={styles.insightItem}>
                  <Text style={styles.insightLabel}>Top Category</Text>
                  <Text style={styles.insightValue}>
                    {categories && categories.length > 0
                      ? categories.reduce((max, cat) =>
                          cat.spent > max.spent ? cat : max,
                        ).name
                      : "N/A"}
                  </Text>
                </View>
              </View>
            </View>
          )}
        </TouchableOpacity>

        {/* Budget Alerts */}
        {(onlineAlert || cashAlert) && (
          <View style={styles.alertsContainer}>
            {onlineAlert && (
              <View
                style={[
                  styles.alertCard,
                  {
                    borderLeftColor:
                      onlineAlert.level === "critical" ? "#EF4444" : "#F59E0B",
                  },
                ]}
              >
                <View style={styles.alertHeader}>
                  <Ionicons
                    name={
                      onlineAlert.level === "critical"
                        ? "alert-circle"
                        : "alert"
                    }
                    size={20}
                    color={
                      onlineAlert.level === "critical" ? "#EF4444" : "#F59E0B"
                    }
                  />
                  <Text
                    style={[
                      styles.alertTitle,
                      {
                        color:
                          onlineAlert.level === "critical"
                            ? "#EF4444"
                            : "#F59E0B",
                      },
                    ]}
                  >
                    {onlineAlert.level === "critical"
                      ? "Budget Exceeded"
                      : "Budget Warning"}
                  </Text>
                </View>
                <Text style={styles.alertText}>
                  Online: {Math.round(onlineAlert.percentage)}% spent of ₹
                  {onlineBudget}
                </Text>
              </View>
            )}

            {cashAlert && (
              <View
                style={[
                  styles.alertCard,
                  {
                    borderLeftColor:
                      cashAlert.level === "critical" ? "#EF4444" : "#F59E0B",
                  },
                ]}
              >
                <View style={styles.alertHeader}>
                  <Ionicons
                    name={
                      cashAlert.level === "critical" ? "alert-circle" : "alert"
                    }
                    size={20}
                    color={
                      cashAlert.level === "critical" ? "#EF4444" : "#F59E0B"
                    }
                  />
                  <Text
                    style={[
                      styles.alertTitle,
                      {
                        color:
                          cashAlert.level === "critical"
                            ? "#EF4444"
                            : "#F59E0B",
                      },
                    ]}
                  >
                    {cashAlert.level === "critical"
                      ? "Budget Exceeded"
                      : "Budget Warning"}
                  </Text>
                </View>
                <Text style={styles.alertText}>
                  Cash: {Math.round(cashAlert.percentage)}% spent of ₹
                  {cashBudget}
                </Text>
              </View>
            )}
          </View>
        )}

        {/* Spending Health Meter */}
        <View style={styles.healthMeterContainer}>
          <Text style={styles.healthTitle}>Spending Health</Text>
          <View style={{ alignItems: "center", marginVertical: 20 }}>
            <SpendingHealthMeter
              score={spendingHealth}
              color={getHealthColor()}
            />
            <View style={{ marginTop: 15, alignItems: "center" }}>
              <Text style={[styles.healthScore, { color: getHealthColor() }]}>
                {Math.round(spendingHealth)}%
              </Text>
              <Text style={styles.healthStatus}>
                {spendingHealth >= 70
                  ? "Excellent Spending Control"
                  : spendingHealth >= 40
                    ? "Moderate Spending"
                    : "High Spending Alert"}
              </Text>
            </View>
          </View>
        </View>

        {/* Spending Trend Chart - Fixed alignment and horizontal scroll */}
        <View style={styles.chartContainer}>
          <Text style={styles.chartTitle}>7-Day Spending Trend</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            scrollEnabled={Dimensions.get("window").width - 40 < Dimensions.get("window").width}
            contentContainerStyle={{ alignItems: "center" }}
          >
            <LineChart
              data={chartData}
              width={Dimensions.get("window").width - 40}
              height={220}
              chartConfig={{
                backgroundColor: "#F9FAFB",
                backgroundGradientFrom: "#F9FAFB",
                backgroundGradientTo: "#F9FAFB",
                decimalPlaces: 0,
                color: (opacity = 1) => "#667085",
                labelColor: (opacity = 1) => "#667085",
                propsForDots: {
                  r: "4",
                  strokeWidth: "2",
                  stroke: "#FFFFFF",
                },
              }}
              bezier
              style={{
                marginVertical: 8,
                borderRadius: 16,
              }}
            />
          </ScrollView>
          <View style={styles.legendContainer}>
            <View style={styles.legendItem}>
              <View
                style={[styles.legendDot, { backgroundColor: "#F87171" }]}
              />
              <Text style={styles.legendText}>Actual Spending</Text>
            </View>
            <View style={styles.legendItem}>
              <View
                style={[
                  styles.legendDot,
                  {
                    backgroundColor: "#A5B4FC",
                    borderWidth: 1,
                    borderColor: "#A5B4FC",
                  },
                ]}
              />
              <Text style={styles.legendText}>Baseline</Text>
            </View>
          </View>
        </View>

        {/* Improved Zero Date Dashboard */}
        <View
          style={[
            styles.predictionCard,
            {
              backgroundColor: getHealthColor() + "15",
              borderLeftColor: getHealthColor(),
            },
          ]}
        >
          <View style={styles.predictionHeader}>
            <Ionicons
              name="calendar-outline"
              size={24}
              color={getHealthColor()}
            />
            <View style={{ flex: 1, marginLeft: 12 }}>
              <Text style={[styles.pTitle, { color: getHealthColor() }]}>
                Money Runway
              </Text>
              <Text style={styles.pSub}>Days until balance depletes</Text>
            </View>
          </View>
          <View style={styles.predictionContent}>
            <Text style={[styles.pVal, { color: getHealthColor() }]}>
              {projectedDaysLeft >= 999 ? "∞" : projectedDaysLeft} Days
            </Text>
            {totalSpent > 0 && (
              <Text style={styles.pDetail}>
                Average: ₹{Math.round(totalSpent / 30)}/day
              </Text>
            )}
            <View style={styles.projectionBars}>
              <View
                style={[
                  styles.projBar,
                  {
                    flex: 1,
                    backgroundColor: getHealthColor(),
                    marginRight: 8,
                  },
                ]}
              >
                <Text style={styles.projText}>{Math.round(onlineBal)}</Text>
              </View>
              <View
                style={[
                  styles.projBar,
                  { flex: 1, backgroundColor: getHealthColor() + "80" },
                ]}
              >
                <Text style={styles.projText}>{Math.round(cashBal)}</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* FAB - Bottom Right */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => {
          // Set default category to "Other"
          const otherCategory = categories.find((cat) => cat.id === "0");
          setSelectedCategory(otherCategory || null);
          setTxnModal(true);
        }}
      >
        <Ionicons name="add" size={35} color="white" />
      </TouchableOpacity>

      {/* Modal: Add Transaction */}
      <Modal visible={txnModal} animationType="slide" transparent={true}>
        <View style={styles.txnModalBackdrop}>
          <View style={styles.txnModal}>
            <Text style={styles.setupTitle}>Add Transaction</Text>
            <TextInput
              placeholder="Title"
              style={styles.input}
              value={title}
              onChangeText={setTitle}
            />
            <TextInput
              placeholder="Amount (₹)"
              style={styles.input}
              keyboardType="numeric"
              value={amt}
              onChangeText={setAmt}
            />

            <View
              style={{ flexDirection: "row", justifyContent: "space-between" }}
            >
              <TouchableOpacity
                style={[
                  styles.modeBtn,
                  mode === "online" && styles.modeBtnActive,
                ]}
                onPress={() => setMode("online")}
              >
                <Text style={{ color: mode === "online" ? "#fff" : "#101828" }}>
                  Online
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.modeBtn,
                  mode === "cash" && styles.modeBtnActive,
                ]}
                onPress={() => setMode("cash")}
              >
                <Text style={{ color: mode === "cash" ? "#fff" : "#101828" }}>
                  Cash
                </Text>
              </TouchableOpacity>
            </View>

            {/* Category Selection with Icons */}
            <Text style={styles.categoryLabel}>Category</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.categoryScroll}
            >
              {categories.map((cat) => (
                <TouchableOpacity
                  key={cat.id}
                  style={[
                    styles.categoryBtn,
                    selectedCategory?.id === cat.id && styles.categoryBtnActive,
                    {
                      borderColor: cat.color,
                      backgroundColor:
                        selectedCategory?.id === cat.id ? cat.color : "#FFFFFF",
                    },
                  ]}
                  onPress={() => setSelectedCategory(cat)}
                >
                  <Text
                    style={{
                      color:
                        selectedCategory?.id === cat.id ? "#fff" : cat.color,
                      fontWeight: "700",
                      fontSize: 13,
                    }}
                  >
                    {cat.icon} {cat.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            <View style={{ flexDirection: "row", marginTop: 12 }}>
              <TouchableOpacity
                style={[styles.btn, { flex: 1, marginRight: 6 }]}
                onPress={() => {
                  const amountNum = parseFloat(amt) || 0;

                  //  Validate amount is entered and not zero
                  if (!amt || amountNum <= 0) {
                    alert(
                      "Please enter a valid amount before adding the expense",
                    );
                    return;
                  }

                  // 🔒 Prevent negative balance
                  if (mode === "online" && amountNum > onlineBal) {
                    alert("Insufficient Online Balance");
                    return;
                  }

                  if (mode === "cash" && amountNum > cashBal) {
                    alert("Insufficient Cash Balance");
                    return;
                  }

                  const txn = {
                    title: title || "Txn",
                    amount: amountNum,
                    mode,
                    type: "expense",
                    category: selectedCategory ? selectedCategory.id : null,
                  };

                  saveTxnToCloud(txn); // 👈 ADD THIS
                  setTitle("");
                  setAmt("");
                  setMode("online");
                  setSelectedCategory(null);
                  setTxnModal(false);
                }}
              >
                <Text style={{ color: "#fff", fontWeight: "bold" }}>Add</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.btn,
                  { flex: 1, backgroundColor: "#EAECF0", marginLeft: 6 },
                ]}
                onPress={() => {
                  setTitle("");
                  setAmt("");
                  setMode("online");
                  setSelectedCategory(null);
                  setTxnModal(false);
                }}
              >
                <Text style={{ color: "#101828", fontWeight: "bold" }}>
                  Cancel
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

// Spending Health Meter Component (Progress Ring/Speedometer)
const SpendingHealthMeter = ({ score, color }) => {
  const radius = 70;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (score / 100) * circumference;

  // Draw colored zones
  const drawZones = () => {
    return (
      <>
        {/* Background circle */}
        <Circle
          cx="90"
          cy="90"
          r={radius}
          fill="none"
          stroke="#E5E7EB"
          strokeWidth="8"
        />
        {/* Progress Arc */}
        <Circle
          cx="90"
          cy="90"
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="10"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          rotation="-90"
          origin="90, 90"
        />
        {/* Center circle background */}
        <Circle cx="90" cy="90" r="45" fill="#fff" />
      </>
    );
  };

  return (
    <Svg width="180" height="180" viewBox="0 0 180 180">
      <G>{drawZones()}</G>
    </Svg>
  );
};

// Reusable Budget Card Component
const BudgetCard = ({ label, spent, total, color }) => {
  const progress = total > 0 ? Math.min(spent / total, 1) : 0;
  return (
    <View style={styles.bCard}>
      <Text style={styles.bLabel}>{label}</Text>
      <Text style={styles.bAmt}>
        ₹{spent} / ₹{total}
      </Text>
      <View style={styles.barBase}>
        <View
          style={[
            styles.barFill,
            { width: `${progress * 100}%`, backgroundColor: color },
          ]}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#F8F9FF" },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 50,
    marginBottom: 32,
    paddingHorizontal: 0,
  },
  title: {
    fontSize: 28,
    fontWeight: "900",
    color: "#1F2937",
    letterSpacing: -0.5,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1F2937",
    marginBottom: 12,
    paddingHorizontal: 20,
    paddingTop: 16,
  },

  // Alert Styles
  alertsContainer: { marginBottom: 24 },
  alertCard: {
    backgroundColor: "#FFFFFF",
    padding: 16,
    borderRadius: 16,
    marginBottom: 12,
    borderLeftWidth: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  alertHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
  },
  alertTitle: { fontWeight: "700", fontSize: 14, marginLeft: 10 },
  alertText: { fontSize: 13, color: "#6B7280", marginLeft: 30 },

  // Category Styles
  categoryLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: "#374151",
    marginTop: 14,
    marginBottom: 12,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  categoryScroll: { marginBottom: 16 },
  categoryBtn: {
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 24,
    backgroundColor: "#FFFFFF",
    marginRight: 10,
    borderWidth: 2,
    borderColor: "#E5E7EB",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  categoryBtnActive: {
    borderColor: "transparent",
  },

  // Health Meter Styles
  healthMeterContainer: {
    backgroundColor: "#FFFFFF",
    padding: 24,
    borderRadius: 20,
    marginBottom: 24,
    borderWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 5,
  },
  healthTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1F2937",
    marginBottom: 24,
  },
  healthScore: {
    fontSize: 40,
    fontWeight: "900",
    marginBottom: 8,
    color: "#667EEA",
  },
  healthStatus: { fontSize: 13, color: "#6B7280", fontWeight: "500" },

  // Chart Styles
  chartContainer: {
    backgroundColor: "#FFFFFF",
    padding: 24,
    borderRadius: 20,
    marginBottom: 24,
    borderWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 5,
  },
  chartTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1F2937",
    marginBottom: 18,
  },
  chart: { borderRadius: 12, marginVertical: 12 },
  legendContainer: {
    flexDirection: "row",
    justifyContent: "center",
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: "#F3F4F6",
  },
  legendItem: {
    flexDirection: "row",
    alignItems: "center",
    marginHorizontal: 16,
  },
  legendDot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
  legendText: { fontSize: 12, color: "#6B7280", fontWeight: "500" },

  budgetSection: { marginBottom: 24 },
  bCard: {
    backgroundColor: "#FFFFFF",
    padding: 18,
    borderRadius: 18,
    marginBottom: 14,
    borderWidth: 0,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 4,
  },
  bLabel: { fontSize: 12, color: "#6B7280", fontWeight: "600" },
  bAmt: {
    fontSize: 18,
    fontWeight: "800",
    marginVertical: 10,
    color: "#1F2937",
  },
  barBase: { height: 10, backgroundColor: "#F0F1F9", borderRadius: 6 },
  barFill: { height: 10, borderRadius: 6 },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 24,
  },
  balanceBox: {
    width: "48%",
    padding: 20,
    borderRadius: 20,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 6,
  },
  label: { fontSize: 11, color: "rgba(255,255,255,0.75)", fontWeight: "600" },
  val: { fontSize: 26, fontWeight: "800", marginTop: 12, color: "#fff" },

  // Improved Prediction Card Styles
  predictionCard: {
    padding: 20,
    borderRadius: 16,
    marginTop: 20,
    marginBottom: 20,
    borderWidth: 1,
  },
  predictionHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 16,
  },
  pTitle: { fontWeight: "600", fontSize: 16 },
  pSub: { color: "#667085", fontSize: 12, marginTop: 2, fontWeight: "500" },
  predictionContent: { marginLeft: 0 },
  pVal: { fontSize: 36, fontWeight: "bold", marginVertical: 10 },
  pDetail: {
    color: "#667085",
    fontSize: 13,
    marginBottom: 14,
    fontWeight: "500",
  },
  projectionBars: {
    flexDirection: "row",
    marginTop: 14,
    height: 50,
    borderRadius: 12,
    overflow: "hidden",
  },
  projBar: {
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 8,
  },
  projText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 13,
  },

  fab: {
    position: "absolute",
    bottom: 30,
    right: 30,
    backgroundColor: "#667EEA",
    width: 70,
    height: 70,
    borderRadius: 35,
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#667EEA",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 10,
  },
  setupContainer: {
    flex: 1,
    justifyContent: "center",
    padding: 30,
    backgroundColor: "#fff",
  },
  setupTitle: { fontSize: 24, fontWeight: "bold", textAlign: "center" },
  setupSub: {
    color: "#667085",
    textAlign: "center",
    marginBottom: 30,
    marginTop: 10,
  },
  setupHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  input: {
    backgroundColor: "#F9FAFB",
    padding: 18,
    borderRadius: 15,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#E5E7EB",
  },
  btn: {
    backgroundColor: "#101828",
    padding: 20,
    borderRadius: 15,
    alignItems: "center",
    marginTop: 10,
  },
  txnModalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "center",
    padding: 20,
  },
  txnModal: { backgroundColor: "#fff", borderRadius: 16, padding: 20 },
  modeBtn: {
    flex: 1,
    padding: 12,
    borderRadius: 10,
    backgroundColor: "#F3F4F6",
    alignItems: "center",
    marginRight: 8,
  },
  modeBtnActive: { backgroundColor: "#101828" },
  datePickerBtn: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F9FAFB",
    borderWidth: 1,
    borderColor: "#EAECF0",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginBottom: 12,
  },
  datePickerText: {
    flex: 1,
    marginLeft: 8,
    fontSize: 14,
    color: "#101828",
    fontWeight: "500",
  },
  dateGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 12,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#EAECF0",
  },
  dateGridBtn: {
    width: "20%",
    aspectRatio: 1,
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 8,
    marginBottom: 8,
    backgroundColor: "#F9FAFB",
    borderWidth: 1,
    borderColor: "#EAECF0",
  },
  dateGridBtnActive: {
    backgroundColor: "#101828",
    borderColor: "#101828",
  },
  dateGridText: {
    fontSize: 13,
    fontWeight: "600",
    color: "#667085",
  },
  dateGridTextActive: {
    color: "#fff",
  },
  monthlySummaryCard: {
    backgroundColor: "#FFFFFF",
    borderRadius: 20,
    borderWidth: 0,
    marginBottom: 24,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 12,
    elevation: 5,
  },
  monthlySummaryHeader: {
    padding: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "linear-gradient(135deg, #667EEA 0%, #764BA2 100%)",
  },
  monthlySummaryLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: "rgba(255,255,255,0.8)",
    marginBottom: 6,
  },
  monthlySummaryAmount: {
    fontSize: 28,
    fontWeight: "800",
    color: "#FFFFFF",
  },
  monthlySummaryPreview: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingHorizontal: 20,
    paddingBottom: 20,
    borderTopWidth: 1,
    borderTopColor: "#F3F4F6",
  },
  previewItem: {
    alignItems: "center",
  },
  previewLabel: {
    fontSize: 12,
    color: "#6B7280",
    marginBottom: 6,
    fontWeight: "500",
  },
  previewValue: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1F2937",
  },
  monthlySummaryChart: {
    paddingHorizontal: 10,
    paddingTop: 0,
    paddingBottom: 16,
    backgroundColor: "#F8F9FF",
  },
  chartSubtitle: {
    fontSize: 12,
    fontWeight: "700",
    color: "#374151",
    marginTop: 12,
    marginBottom: 12,
    paddingHorizontal: 10,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  monthlyInsights: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingHorizontal: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: "#E5E7EB",
  },
  insightItem: {
    alignItems: "center",
    flex: 1,
  },
  insightDivider: {
    width: 1,
    backgroundColor: "#E5E7EB",
  },
  insightLabel: {
    fontSize: 11,
    color: "#6B7280",
    marginBottom: 4,
    fontWeight: "500",
    textTransform: "uppercase",
  },
  insightValue: {
    fontSize: 14,
    fontWeight: "700",
    color: "#1F2937",
  },
});