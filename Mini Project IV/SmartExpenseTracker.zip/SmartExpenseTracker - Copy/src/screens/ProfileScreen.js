import { Ionicons } from "@expo/vector-icons";
import { updateEmail, updateProfile } from "firebase/auth";
import { useContext, useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { auth } from "../../firebase";
import { AppContext } from "../context/AppContext";

export default function ProfileScreen({ navigation }) {
  const { profile, setProfile, logout, deleteAccount } = useContext(AppContext);

  const [editModal, setEditModal] = useState(false);
  const [newName, setNewName] = useState(profile?.username || "");
  const [newEmail, setNewEmail] = useState(profile?.email || "");
  const [deleting, setDeleting] = useState(false);

  const handleUpdateProfile = async () => {
    try {
      const user = auth.currentUser;
      if (!user) return;

      // 1. Update Name (DisplayName)
      if (newName !== profile.username) {
        await updateProfile(user, { displayName: newName });
      }

      // 2. Update Email (Requires recent login)
      if (newEmail !== profile.email) {
        await updateEmail(user, newEmail);
      }

      // 3. Update Global Context State (Ensures it stays saved in the app)
      setProfile({
        ...profile,
        username: newName,
        email: newEmail,
      });

      setEditModal(false);

      const successMsg = "Profile updated successfully!";
      Platform.OS === "web"
        ? window.alert(successMsg)
        : Alert.alert("Success", successMsg);
    } catch (error) {
      console.error(error);
      const errorMsg =
        error.code === "auth/requires-recent-login"
          ? "Please log out and log back in to change your email for security."
          : "Failed to update profile. Check your internet.";

      Platform.OS === "web"
        ? window.alert(errorMsg)
        : Alert.alert("Error", errorMsg);
    }
  };

  // NEW: Dedicated function to handle the deletion and navigation cleanly across platforms
  const executeDelete = async () => {
    console.log("🔴 Delete confirmation pressed");
    setDeleting(true);
    try {
      console.log("🔴 Calling deleteAccount()...");
      await deleteAccount();
      console.log("✅ deleteAccount() completed successfully");
      
      const successMsg = "Your account has been permanently deleted.";
      
      if (Platform.OS === "web") {
        window.alert(successMsg);
        navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
      } else {
        Alert.alert("Success", successMsg, [
          {
            text: "OK",
            onPress: () => {
              navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
            }
          }
        ]);
      }
    } catch (error) {
      console.error('❌ Delete failed with error:', error);
      
      let errorMsg = "Failed to delete account. Check your internet connection.";
      if (error.code === "auth/requires-recent-login") {
        errorMsg = "Please log out and log back in to delete your account for security.";
      } else if (error.message) {
        errorMsg = error.message;
      }
      
      if (Platform.OS === "web") {
        window.alert(errorMsg);
      } else {
        Alert.alert("Error", errorMsg);
      }
      setDeleting(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: "#FFFFFF" }]}>
      {/* Header */}
      <View style={styles.navHeader}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="arrow-back" size={28} color="#101828" />
        </TouchableOpacity>
        <Text style={[styles.navTitle, { color: "#101828" }]}>My Profile</Text>
        <View style={{ width: 28 }} />
      </View>

      <View style={styles.profileHeader}>
        <View style={styles.avatarContainer}>
          <Ionicons name="person-circle" size={100} color="#667EEA" />
          <TouchableOpacity
            style={styles.editIconCircle}
            onPress={() => {
              setNewName(profile.username);
              setNewEmail(profile.email);
              setEditModal(true);
            }}
          >
            <Ionicons name="pencil" size={16} color="#FFF" />
          </TouchableOpacity>
        </View>
        <Text style={[styles.username, { color: "#101828" }]}>
          {profile?.username || "User"}
        </Text>
        <Text style={[styles.email, { color: "#667085" }]}>
          {profile?.email}
        </Text>
      </View>

      <View style={styles.actions}>
        <TouchableOpacity style={styles.logoutBtn} onPress={logout}>
          <Ionicons name="log-out-outline" size={20} color="#FFF" />
          <Text style={styles.btnText}>Log Out</Text>
        </TouchableOpacity>

        {/* UPDATED: Delete Button logic with Platform Check */}
        <TouchableOpacity 
          style={[styles.deleteBtn, deleting && { opacity: 0.6 }]} 
          disabled={deleting}
          onPress={() => {
            const warningMsg = "⚠️  This will permanently delete your account and all data. This cannot be undone.";

            if (Platform.OS === "web") {
              const confirm = window.confirm(warningMsg);
              if (confirm) {
                executeDelete();
              }
            } else {
              Alert.alert(
                "Delete Account",
                warningMsg,
                [
                  { text: "Cancel", onPress: () => {}, style: "cancel" },
                  { text: "Delete Everything", onPress: executeDelete, style: "destructive" }
                ]
              );
            }
          }}
        >
          <Ionicons name="trash-outline" size={20} color="#EF4444" />
          <Text style={[styles.deleteText, deleting && { opacity: 0.6 }]}>
            Delete Account{deleting && '...'}
          </Text>
        </TouchableOpacity>
      </View>

      {/* Edit Modal for Name and Email */}
      <Modal visible={editModal} transparent animationType="slide">
        <View style={styles.modalBackdrop}>
          <View style={[styles.modalContent, { backgroundColor: "#FFFFFF" }]}>
            <Text style={[styles.modalTitle, { color: "#101828" }]}>
              Edit Profile
            </Text>

            <Text style={styles.inputLabel}>Full Name</Text>
            <TextInput
              style={[styles.input, { color: "#101828" }]}
              value={newName}
              onChangeText={setNewName}
              placeholder="Your Name"
              placeholderTextColor="#999"
            />

            <Text style={styles.inputLabel}>Email Address</Text>
            <TextInput
              style={[styles.input, { color: "#101828" }]}
              value={newEmail}
              onChangeText={setNewEmail}
              placeholder="Your Email"
              placeholderTextColor="#999"
              keyboardType="email-address"
              autoCapitalize="none"
            />

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.saveBtn}
                onPress={handleUpdateProfile}
              >
                <Text style={styles.btnText}>Save Changes</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setEditModal(false)}>
                <Text style={[styles.cancelText, { color: "#667085" }]}>
                  Cancel
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  navHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 40,
    marginBottom: 20,
  },
  navTitle: { fontSize: 20, fontWeight: "bold" },
  profileHeader: { alignItems: "center", marginBottom: 40 },
  avatarContainer: { position: "relative" },
  editIconCircle: {
    position: "absolute",
    bottom: 5,
    right: 5,
    backgroundColor: "#667EEA",
    borderRadius: 15,
    padding: 6,
    borderWidth: 2,
    borderColor: "#FFF",
  },
  username: { fontSize: 26, fontWeight: "bold", marginTop: 15 },
  email: { fontSize: 16, marginTop: 5 },
  actions: { gap: 15 },
  logoutBtn: {
    backgroundColor: "#101828",
    flexDirection: "row",
    padding: 16,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
  },
  btnText: { color: "#FFF", fontWeight: "bold", fontSize: 16 },
  deleteBtn: {
    backgroundColor: "#FEF2F2",
    flexDirection: "row",
    padding: 16,
    borderRadius: 14,
    justifyContent: "center",
    alignItems: "center",
    gap: 8,
    borderWidth: 1,
    borderColor: "#FECACA",
  },
  deleteText: { color: "#EF4444", fontWeight: "bold", fontSize: 16 },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    padding: 20,
  },
  modalContent: { padding: 25, borderRadius: 20 },
  modalTitle: { fontSize: 20, fontWeight: "bold", marginBottom: 15 },
  inputLabel: {
    fontSize: 14,
    fontWeight: "600",
    color: "#667085",
    marginBottom: 5,
    marginTop: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: "#EAECF0",
    padding: 12,
    borderRadius: 10,
    fontSize: 16,
    marginBottom: 10,
  },
  modalButtons: { gap: 12, alignItems: "center", marginTop: 15 },
  saveBtn: {
    backgroundColor: "#667EEA",
    padding: 15,
    borderRadius: 12,
    width: "100%",
    alignItems: "center",
  },
  cancelText: { fontWeight: "bold", fontSize: 14 },
});