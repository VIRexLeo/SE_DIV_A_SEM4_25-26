import { useContext } from "react";
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { AppContext } from "../context/AppContext";

export default function DebugContextScreen() {
  const ctx = useContext(AppContext);

  return (
    <View style={styles.container}>
      <Text style={styles.header}>AppContext Debug</Text>
      <TouchableOpacity
        style={styles.btn}
        onPress={() => console.log("AppContext:", ctx)}
      >
        <Text style={styles.btnText}>Log context to console</Text>
      </TouchableOpacity>

      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.json}>{JSON.stringify(ctx, null, 2)}</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#fff" },
  header: { fontSize: 20, fontWeight: "bold", marginBottom: 12 },
  btn: {
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 10,
    alignItems: "center",
    marginBottom: 12,
  },
  btnText: { color: "#101828", fontWeight: "bold" },
  scroll: { paddingBottom: 60 },
  json: { fontFamily: undefined, fontSize: 12, color: "#111" },
});
