import { Ionicons } from "@expo/vector-icons";
import { ref, set } from "firebase/database";
import { useContext, useEffect, useRef, useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { auth, db } from "../../firebase";
import { AppContext } from "../context/AppContext";

export default function CategoryScreen() {
  const {
    categories,
    addCategory,
    updateCategorySpend,
    updateCategory,
    updateCategoryColor,
    deleteCategory,
    undoDeleteCategory,
    onlineBal,
    cashBal,
  } = useContext(AppContext);

  if (!updateCategory) console.warn("AppContext: updateCategory is undefined");
  if (!deleteCategory) console.warn("AppContext: deleteCategory is undefined");

  const safeUpdateCategory =
    updateCategory ||
    ((id, data) => {
      Alert.alert("Error", "Update action not available");
    });
  const safeDeleteCategory =
    deleteCategory ||
    ((id) => {
      Alert.alert("Error", "Delete action not available");
      return null;
    });

  const [modalVisible, setModalVisible] = useState(false);
  const [newCatName, setNewCatName] = useState("");
  const [newCatLimit, setNewCatLimit] = useState("");

  const [spendModal, setSpendModal] = useState(false);
  const [selectedCatId, setSelectedCatId] = useState(null);
  const [spendAmt, setSpendAmt] = useState("");
  const [editModal, setEditModal] = useState(false);
  const [colorModal, setColorModal] = useState(false);
  const [selectedCatForColor, setSelectedCatForColor] = useState(null);
  const [newCategoryColorModal, setNewCategoryColorModal] = useState(false);
  const [newCatColor, setNewCatColor] = useState("#FF6B6B");
  const [lastDeleted, setLastDeleted] = useState(null);
  const undoTimer = useRef(null);

  const colorOptions = [
    "#FF6B6B",
    "#4ECDC4",
    "#45B7D1",
    "#FFA07A",
    "#98D8C8",
    "#F7DC6F",
    "#667BC6",
    "#E77F67",
    "#A0522D",
    "#20B2AA",
    "#DC143C",
    "#FFD700",
    "#9370DB",
    "#FF4500",
    "#00CED1",
    "#32CD32",
  ];

  // 🔥 Persist categories to Firebase whenever they change
  useEffect(() => {
    const user = auth.currentUser;
    if (!user || !categories) return;

    const persistCategories = async () => {
      try {
        await set(ref(db, `categories/${user.uid}`), categories);
        console.log("✅ Categories persisted to Firebase");
      } catch (error) {
        console.error("❌ Error persisting categories:", error);
      }
    };

    persistCategories();
  }, [categories]);

  const handleAddCategory = () => {
    // ✅ Validate inputs
    if (!newCatName.trim()) {
      Alert.alert("Missing Field", "Please enter a category name", [
        { text: "OK", onPress: () => {} },
      ]);
      return;
    }

    if (!newCatLimit.trim()) {
      Alert.alert("Missing Field", "Please enter a monthly limit", [
        { text: "OK", onPress: () => {} },
      ]);
      return;
    }

    const limitNum = parseFloat(newCatLimit);
    if (isNaN(limitNum) || limitNum <= 0) {
      Alert.alert("Invalid Amount", "Limit must be a number greater than 0", [
        { text: "OK", onPress: () => {} },
      ]);
      return;
    }

    addCategory(newCatName, newCatLimit, newCatColor);
    setModalVisible(false);
    setNewCatName("");
    setNewCatLimit("");
    setNewCatColor("#FF6B6B");
  };

  const handleManualSpend = () => {
    console.log("🔍 Spend handler - Amount:", spendAmt, "Balance:", onlineBal);

    // ✅ CHECK 1: Amount cannot be empty
    if (!spendAmt || spendAmt.trim() === "") {
      Alert.alert(
        "⚠️ Missing Amount",
        "Please enter an amount to log spending.",
        [{ text: "OK", onPress: () => {} }],
      );
      return;
    }

    // ✅ CHECK 2: Amount must be a valid number
    const amt = parseFloat(spendAmt);
    if (isNaN(amt)) {
      Alert.alert("⚠️ Invalid Amount", "Please enter a valid number.", [
        { text: "OK", onPress: () => {} },
      ]);
      return;
    }

    // ✅ CHECK 3: Amount must be greater than 0
    if (amt <= 0) {
      Alert.alert("⚠️ Invalid Amount", "Amount must be greater than 0.", [
        { text: "OK", onPress: () => {} },
      ]);
      return;
    }

    // ✅ CHECK 4: Category must be selected
    if (!selectedCatId) {
      Alert.alert("⚠️ No Category", "Please select a category first.", [
        { text: "OK", onPress: () => {} },
      ]);
      return;
    }

    // 💰 CHECK 5: Balance cannot be zero or negative
    if (onlineBal <= 0) {
      Alert.alert(
        "💰 Zero Balance",
        `Your balance is Rs${onlineBal}. You cannot log spending when balance is zero or negative.`,
        [{ text: "OK", onPress: () => {} }],
      );
      return;
    }

    // ✅ All validations passed - log the spend
    try {
      updateCategorySpend(selectedCatId, spendAmt);
      Alert.alert("✅ Success", `Rs${amt} logged for this category!`, [
        { text: "OK", onPress: () => {} },
      ]);
      setSpendModal(false);
      setSpendAmt("");
    } catch (error) {
      console.error("❌ Error:", error);
      Alert.alert("❌ Error", "Failed to log spending. Try again.", [
        { text: "OK", onPress: () => {} },
      ]);
    }
  };

  const handleEditCategory = () => {
    // ✅ Validate inputs
    if (!newCatName.trim()) {
      Alert.alert("Missing Field", "Please enter a category name", [
        { text: "OK", onPress: () => {} },
      ]);
      return;
    }

    if (!newCatLimit.trim()) {
      Alert.alert("Missing Field", "Please enter a monthly limit", [
        { text: "OK", onPress: () => {} },
      ]);
      return;
    }

    const limitNum = parseFloat(newCatLimit);
    if (isNaN(limitNum) || limitNum <= 0) {
      Alert.alert("Invalid Amount", "Limit must be a number greater than 0", [
        { text: "OK", onPress: () => {} },
      ]);
      return;
    }

    safeUpdateCategory(selectedCatId, { name: newCatName, limit: newCatLimit });
    setEditModal(false);
    setNewCatName("");
    setNewCatLimit("");
  };

  const handleDeleteCategory = (categoryId) => {
    if (Platform.OS === "web") {
      const confirmDelete = window.confirm(
        "Are you sure you want to delete this category?",
      );
      if (confirmDelete) {
        const result = safeDeleteCategory(categoryId);
        if (result) {
          setLastDeleted(result);
          // Auto-remove undo bar after 5 seconds
          if (undoTimer.current) clearTimeout(undoTimer.current);
          undoTimer.current = setTimeout(() => {
            setLastDeleted(null);
          }, 5000);
        }
      }
    } else {
      Alert.alert(
        "Delete Category",
        "Are you sure you want to delete this category?",
        [
          { text: "Cancel", style: "cancel" },
          {
            text: "Delete",
            style: "destructive",
            onPress: () => {
              const result = safeDeleteCategory(categoryId);
              if (result) {
                setLastDeleted(result);
                // Auto-remove undo bar after 5 seconds
                if (undoTimer.current) clearTimeout(undoTimer.current);
                undoTimer.current = setTimeout(() => {
                  setLastDeleted(null);
                }, 5000);
              }
            },
          },
        ],
      );
    }
  };

  const handleUndo = () => {
    if (!lastDeleted) return;
    undoDeleteCategory(lastDeleted.deletedCat, lastDeleted.txnId);
    setLastDeleted(null);
    if (undoTimer.current) {
      clearTimeout(undoTimer.current);
      undoTimer.current = null;
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Category Limits</Text>
        <TouchableOpacity
          style={styles.addBtn}
          onPress={() => setModalVisible(true)}
        >
          <Ionicons name="add-circle" size={30} color="#101828" />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 100 }}>
        {categories.length === 0 ? (
          <View style={styles.emptyState}>
            <Ionicons name="folder-open-outline" size={48} color="#D1D5DB" />
            <Text style={{ color: "#9CA3AF", marginTop: 8, fontSize: 16 }}>
              No categories yet. Create one to get started!
            </Text>
          </View>
        ) : (
          categories.map((cat) => {
            const isOver = cat.spent > cat.limit;
            const progress = Math.min(cat.spent / cat.limit, 1);

            return (
              <TouchableOpacity
                key={cat.id}
                style={styles.card}
                onPress={() => {
                  setSelectedCatId(cat.id);
                  setSpendModal(true);
                }}
              >
                <View style={styles.row}>
                  <View
                    style={{
                      flex: 1,
                      flexDirection: "row",
                      alignItems: "center",
                    }}
                  >
                    <View
                      style={{
                        width: 12,
                        height: 12,
                        borderRadius: 6,
                        backgroundColor: cat.color || "#101828",
                        marginRight: 10,
                      }}
                    />
                    <Text style={styles.catName}>{cat.name}</Text>
                  </View>
                  <View style={{ flexDirection: "row", alignItems: "center" }}>
                    <Text
                      style={[
                        styles.status,
                        { color: isOver ? "#D92D20" : "#039855" },
                      ]}
                    >
                      {isOver ? "Overlimit" : "On Track"}
                    </Text>
                    <TouchableOpacity
                      style={{ marginLeft: 12 }}
                      onPress={() => {
                        setSelectedCatForColor(cat);
                        setColorModal(true);
                      }}
                    >
                      <Ionicons
                        name="color-palette"
                        size={18}
                        color="#2E90FA"
                      />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={{ marginLeft: 12 }}
                      onPress={() => {
                        setSelectedCatId(cat.id);
                        setNewCatName(cat.name);
                        setNewCatLimit(String(cat.limit));
                        setEditModal(true);
                      }}
                    >
                      <Ionicons name="pencil" size={18} color="#101828" />
                    </TouchableOpacity>
                    <TouchableOpacity
                      style={{ marginLeft: 12 }}
                      onPress={() => handleDeleteCategory(cat.id)}
                    >
                      <Ionicons name="trash" size={18} color="#D92D20" />
                    </TouchableOpacity>
                  </View>
                </View>

                <View style={styles.barContainer}>
                  <View
                    style={[
                      styles.barFill,
                      {
                        width: `${progress * 100}%`,
                        backgroundColor: isOver ? "#F04438" : "#101828",
                      },
                    ]}
                  />
                </View>

                <View style={styles.row}>
                  <Text style={styles.details}>Spent: ₹{cat.spent}</Text>
                  <Text style={styles.details}>Limit: ₹{cat.limit}</Text>
                </View>
              </TouchableOpacity>
            );
          })
        )}
      </ScrollView>

      {/* Modal: Create New Category */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>New Category</Text>
            <TextInput
              placeholder="Category Name"
              placeholderTextColor="#9CA3AF"
              style={styles.input}
              value={newCatName}
              onChangeText={setNewCatName}
            />
            <TextInput
              placeholder="Monthly Limit (₹)"
              placeholderTextColor="#9CA3AF"
              style={styles.input}
              keyboardType="numeric"
              value={newCatLimit}
              onChangeText={setNewCatLimit}
            />
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 15,
              }}
            >
              <Text style={{ flex: 1, fontSize: 14, fontWeight: "500" }}>
                Color:
              </Text>
              <TouchableOpacity
                style={[styles.colorPreview, { backgroundColor: newCatColor }]}
                onPress={() => setNewCategoryColorModal(true)}
              />
            </View>
            <TouchableOpacity
              style={styles.saveBtn}
              onPress={handleAddCategory}
            >
              <Text style={styles.btnText}>Create Category</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                setModalVisible(false);
                setNewCatColor("#FF6B6B");
                setNewCatName("");
                setNewCatLimit("");
              }}
            >
              <Text style={styles.cancel}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Modal: Manually Add Spend to Category */}
      <Modal visible={spendModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Log Manual Spend</Text>
            <TextInput
              placeholder="Amount Spent (₹)"
              placeholderTextColor="#9CA3AF"
              style={styles.input}
              keyboardType="numeric"
              value={spendAmt}
              onChangeText={setSpendAmt}
            />
            <TouchableOpacity
              style={styles.saveBtn}
              onPress={handleManualSpend}
            >
              <Text style={styles.btnText}>Update Spend</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setSpendModal(false)}>
              <Text style={styles.cancel}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Modal: Edit Category */}
      <Modal visible={editModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Edit Category</Text>
            <TextInput
              placeholder="Category Name"
              placeholderTextColor="#9CA3AF"
              style={styles.input}
              value={newCatName}
              onChangeText={setNewCatName}
            />
            <TextInput
              placeholder="Monthly Limit (₹)"
              placeholderTextColor="#9CA3AF"
              style={styles.input}
              keyboardType="numeric"
              value={newCatLimit}
              onChangeText={setNewCatLimit}
            />
            <TouchableOpacity
              style={styles.saveBtn}
              onPress={handleEditCategory}
            >
              <Text style={styles.btnText}>Save Changes</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setEditModal(false)}>
              <Text style={styles.cancel}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Undo bar */}
      {lastDeleted ? (
        <View style={styles.undoBar}>
          <Text style={{ color: "#fff" }}>
            Deleted {lastDeleted.deletedCat?.name}
          </Text>
          <TouchableOpacity onPress={handleUndo}>
            <Text style={{ color: "#fff", fontWeight: "bold", marginLeft: 12 }}>
              UNDO
            </Text>
          </TouchableOpacity>
        </View>
      ) : null}

      {/* Color Picker Modal */}
      <Modal visible={colorModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Choose Color</Text>
            <View style={styles.colorGrid}>
              {colorOptions.map((color) => (
                <TouchableOpacity
                  key={color}
                  style={[
                    styles.colorOption,
                    { backgroundColor: color },
                    selectedCatForColor?.color === color &&
                      styles.colorOptionActive,
                  ]}
                  onPress={() => {
                    if (selectedCatForColor) {
                      updateCategoryColor(selectedCatForColor.id, color);
                      setColorModal(false);
                      setSelectedCatForColor(null);
                    }
                  }}
                >
                  {selectedCatForColor?.color === color && (
                    <Ionicons name="checkmark" size={24} color="#fff" />
                  )}
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity
              style={[styles.saveBtn, { backgroundColor: "#EAECF0" }]}
              onPress={() => {
                setColorModal(false);
                setSelectedCatForColor(null);
              }}
            >
              <Text style={{ color: "#101828", fontWeight: "bold" }}>
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Color Picker Modal for New Category */}
      <Modal visible={newCategoryColorModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Choose Color</Text>
            <View style={styles.colorGrid}>
              {colorOptions.map((color) => (
                <TouchableOpacity
                  key={color}
                  style={[
                    styles.colorOption,
                    { backgroundColor: color },
                    newCatColor === color && styles.colorOptionActive,
                  ]}
                  onPress={() => {
                    setNewCatColor(color);
                    setNewCategoryColorModal(false);
                  }}
                >
                  {newCatColor === color && (
                    <Ionicons name="checkmark" size={24} color="#fff" />
                  )}
                </TouchableOpacity>
              ))}
            </View>
            <TouchableOpacity
              style={[styles.saveBtn, { backgroundColor: "#EAECF0" }]}
              onPress={() => {
                setNewCategoryColorModal(false);
              }}
            >
              <Text style={{ color: "#101828", fontWeight: "bold" }}>
                Cancel
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff", padding: 20 },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 40,
    marginBottom: 20,
  },
  title: { fontSize: 24, fontWeight: "bold" },
  addBtn: { padding: 5 },
  card: {
    backgroundColor: "#F9FAFB",
    padding: 20,
    borderRadius: 20,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#EAECF0",
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  catName: { fontSize: 18, fontWeight: "bold", color: "#101828" },
  status: { fontSize: 12, fontWeight: "bold" },
  barContainer: {
    height: 10,
    backgroundColor: "#EAECF0",
    borderRadius: 5,
    marginVertical: 12,
    overflow: "hidden",
  },
  barFill: { height: 10, borderRadius: 5 },
  details: { fontSize: 13, color: "#667085" },
  emptyState: { alignItems: "center", marginTop: 100 },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    padding: 20,
  },
  modalContent: { backgroundColor: "white", padding: 30, borderRadius: 25 },
  modalTitle: { fontSize: 20, fontWeight: "bold", marginBottom: 20 },
  input: {
    backgroundColor: "#F9FAFB",
    padding: 15,
    borderRadius: 12,
    marginBottom: 15,
    borderWidth: 1,
    borderColor: "#EAECF0",
    fontSize: 16,
    color: "#101828",
  },
  saveBtn: {
    backgroundColor: "#101828",
    padding: 15,
    borderRadius: 12,
    alignItems: "center",
  },
  btnText: { color: "#fff", fontWeight: "bold" },
  cancel: {
    textAlign: "center",
    marginTop: 15,
    color: "#667085",
    fontWeight: "bold",
  },
  colorGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-around",
    marginBottom: 20,
    gap: 10,
  },
  colorOption: {
    width: "20%",
    aspectRatio: 1,
    borderRadius: 50,
    marginBottom: 10,
    justifyContent: "center",
    alignItems: "center",
    borderWidth: 2,
    borderColor: "transparent",
  },
  colorOptionActive: {
    borderColor: "#101828",
    borderWidth: 3,
  },
  colorPreview: {
    width: 50,
    height: 50,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: "#EAECF0",
  },
  undoBar: {
    position: "absolute",
    left: 20,
    right: 20,
    bottom: 30,
    backgroundColor: "#101828",
    padding: 14,
    borderRadius: 12,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
});
