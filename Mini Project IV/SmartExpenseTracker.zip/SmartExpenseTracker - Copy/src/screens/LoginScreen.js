import { Ionicons } from "@expo/vector-icons";
import {
    createUserWithEmailAndPassword,
    sendEmailVerification,
    sendPasswordResetEmail,
    signInWithEmailAndPassword,
    updateProfile,
} from "firebase/auth";
import { useState } from "react";
import {
    KeyboardAvoidingView,
    Modal,
    Platform,
    SafeAreaView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from "react-native";
import { auth } from "../../firebase";

export default function LoginScreen({ onLogin }) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [resetEmail, setResetEmail] = useState("");

  const handleForgotPassword = async () => {
    if (!resetEmail) {
      alert("Please enter your email");
      return;
    }
    try {
      await sendPasswordResetEmail(auth, resetEmail);
      alert("✅ Password reset email sent! Check your inbox.");
      setResetEmail("");
      setShowForgotModal(false);
    } catch (err) {
      alert("❌ " + err.message);
    }
  };

  const handleAuth = async () => {
    if (!email || !password) {
      alert("Please fill all fields");
      return;
    }

    try {
      if (isLogin) {
        // LOGIN
        const res = await signInWithEmailAndPassword(auth, email, password);

        if (!res.user.emailVerified) {
          alert("Please verify your email first");
          return;
        }

        alert("Login Successful!");
        onLogin(); // continue to app
      } else {
        // SIGNUP
        if (!name || name.trim() === "") {
          alert("Please enter your name");
          return;
        }

        const userCredential = await createUserWithEmailAndPassword(
          auth,
          email,
          password,
        );

        await updateProfile(userCredential.user, {
          displayName: name.trim(),
        });

        await sendEmailVerification(userCredential.user);

        alert("Account created! Check email for verification.");
        setIsLogin(true);
      }
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.content}
      >
        <View style={styles.headerSection}>
          <Text style={styles.appName}>SmartSpend</Text>
          <Text style={styles.appSubtitle}>
            {isLogin ? "SECURE USER ACCESS" : "JOIN THE MOVE"}
          </Text>
        </View>

        <View style={styles.formCard}>
          <Text style={styles.formTitle}>
            {isLogin ? "LOGIN CREDENTIALS" : "PERSONAL DETAILS"}
          </Text>

          {!isLogin && (
            <View style={styles.inputContainer}>
              <Ionicons name="person-outline" size={20} color="#98A2B3" />
              <TextInput
                placeholder="Full Name"
                style={styles.input}
                value={name}
                onChangeText={setName}
              />
            </View>
          )}

          <View style={styles.inputContainer}>
            <Ionicons name="mail-outline" size={20} color="#98A2B3" />
            <TextInput
              placeholder="Email Address"
              style={styles.input}
              value={email}
              onChangeText={setEmail}
              autoCapitalize="none"
            />
          </View>

          <View style={styles.inputContainer}>
            <Ionicons name="lock-closed-outline" size={20} color="#98A2B3" />
            <TextInput
              placeholder="Password"
              style={styles.input}
              secureTextEntry={!showPassword}
              value={password}
              onChangeText={setPassword}
            />
            <TouchableOpacity
              onPress={() => setShowPassword(!showPassword)}
              style={{ marginLeft: "auto", padding: 5 }}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              <Ionicons
                name={showPassword ? "eye-off-outline" : "eye-outline"}
                size={20}
                color="#98A2B3"
              />
            </TouchableOpacity>
          </View>

          {isLogin && (
            <TouchableOpacity onPress={() => setShowForgotModal(true)}>
              <Text style={styles.forgotText}>Forgot Password?</Text>
            </TouchableOpacity>
          )}
        </View>

        <TouchableOpacity style={styles.mainBtn} onPress={handleAuth}>
          <Text style={styles.mainBtnText}>
            {isLogin ? "Sign In" : "Register"}
          </Text>
          <Ionicons
            name="arrow-forward"
            size={20}
            color="#FFF"
            style={{ marginLeft: 10 }}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.switchMode}
          onPress={() => setIsLogin(!isLogin)}
        >
          <Text style={styles.switchText}>
            {isLogin ? "New here? " : "Already registered? "}
            <Text style={styles.switchLink}>
              {isLogin ? "Create Account" : "Sign In"}
            </Text>
          </Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>

      <Modal visible={showForgotModal} transparent animationType="fade" onRequestClose={() => setShowForgotModal(false)}>
        <View style={[styles.modalBackdrop, { backgroundColor: "rgba(0,0,0,0.5)" }]} pointerEvents="box-none">
          <View style={[styles.modalContent, { backgroundColor: "#FFF" }]} pointerEvents="auto">
            <Text style={styles.modalTitle}>Reset Password</Text>
            <Text style={styles.modalSubtitle}>Enter your email to receive a reset link</Text>

            <TextInput
              placeholder="Email Address"
              style={styles.modalInput}
              value={resetEmail}
              onChangeText={setResetEmail}
              autoCapitalize="none"
              keyboardType="email-address"
            />

            <TouchableOpacity 
              style={styles.modalBtn} 
              onPress={handleForgotPassword}
            >
              <Text style={styles.modalBtnText}>Send Reset Link</Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.modalCancelBtn}
              onPress={() => setShowForgotModal(false)}
            >
              <Text style={styles.modalCancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#FFF" },
  content: { flex: 1, padding: 30, justifyContent: "center" },
  headerSection: { alignItems: "center", marginBottom: 40 },
  appName: { fontSize: 32, fontWeight: "bold", color: "#101828" },
  appSubtitle: {
    fontSize: 12,
    color: "#667085",
    letterSpacing: 1.5,
    marginTop: 5,
  },
  formCard: {
    backgroundColor: "#FFF",
    padding: 25,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: "#EAECF0",
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 10,
  },
  formTitle: {
    fontSize: 11,
    fontWeight: "bold",
    color: "#667085",
    marginBottom: 20,
  },
  inputContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F9FAFB",
    borderRadius: 12,
    paddingHorizontal: 15,
    marginBottom: 15,
    height: 55,
  },
  input: { flex: 1, marginLeft: 10, fontSize: 15, color: "#101828" },
  forgotText: {
    color: "#2E90FA",
    textAlign: "right",
    fontSize: 13,
    fontWeight: "600",
  },
  mainBtn: {
    backgroundColor: "#0C111D",
    flexDirection: "row",
    height: 60,
    borderRadius: 16,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 30,
  },
  mainBtnText: { color: "#FFF", fontSize: 18, fontWeight: "bold" },
  switchMode: { marginTop: 25, alignItems: "center" },
  switchText: { color: "#667085", fontSize: 14 },
  switchLink: { color: "#101828", fontWeight: "bold" },
  modalBackdrop: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    pointerEvents: "box-none",
  },
  modalContent: {
    borderRadius: 20,
    padding: 25,
    width: "100%",
    maxWidth: 400,
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 15,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#101828",
    marginBottom: 8,
  },
  modalSubtitle: {
    fontSize: 14,
    color: "#667085",
    marginBottom: 20,
  },
  modalInput: {
    borderWidth: 1,
    borderColor: "#EAECF0",
    padding: 12,
    borderRadius: 10,
    fontSize: 16,
    marginBottom: 15,
    color: "#101828",
  },
  modalBtn: {
    backgroundColor: "#667EEA",
    padding: 14,
    borderRadius: 10,
    alignItems: "center",
    marginBottom: 10,
  },
  modalBtnText: {
    color: "#FFF",
    fontWeight: "bold",
    fontSize: 16,
  },
  modalCancelBtn: {
    padding: 12,
    alignItems: "center",
  },
  modalCancelText: {
    color: "#667085",
    fontWeight: "600",
    fontSize: 14,
  },
});
