import { Ionicons } from "@expo/vector-icons";
import { useContext, useState } from "react";
import {
  Alert,
  FlatList,
  Modal,
  Platform,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { AppContext } from "../context/AppContext";

// Utility function for relative date display
const getRelativeTime = (dateString) => {
  const now = new Date();
  const date = new Date(dateString);
  const seconds = Math.floor((now - date) / 1000);

  if (seconds < 60) return "Just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;

  return date.toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
    year: date.getFullYear() !== now.getFullYear() ? "numeric" : undefined,
  });
};

export default function HistoryScreen() {
  const { transactions, deleteTransaction, editTransaction, categories } =
    useContext(AppContext);

  const [editModal, setEditModal] = useState(false);
  const [selectedTxn, setSelectedTxn] = useState(null);
  const [editTitle, setEditTitle] = useState("");
  const [editAmount, setEditAmount] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterMode, setFilterMode] = useState("all"); // all, online, cash
  // all, income, expense
  const [filterCategory, setFilterCategory] = useState(null);
  const [showFilters, setShowFilters] = useState(false);
  const [expandedId, setExpandedId] = useState(null);

  const getCategoryName = (categoryId) => {
    if (!categoryId) return null;
    const cat = categories.find((c) => c.id === categoryId);
    return cat?.name;
  };

  const getCategoryIcon = (categoryId) => {
    if (!categoryId) return null;
    const cat = categories.find((c) => c.id === categoryId);
    return cat?.icon;
  };

  const filteredTransactions = transactions.filter((txn) => {
    const matchesSearch =
      txn.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      txn.amount.toString().includes(searchQuery);

    const matchesType = filterType === "all" || txn.type === filterType;

    const matchesCategory = !filterCategory || txn.category === filterCategory;

    const matchesMode = filterMode === "all" || txn.mode === filterMode;

    return matchesSearch && matchesType && matchesCategory && matchesMode;
  });

  const handleDelete = (id, title) => {
    if (Platform.OS === "web") {
      // Web browser confirmation
      const confirmDelete = window.confirm(`Delete "${title}"?`);
      if (confirmDelete) {
        deleteTransaction(id);
        setExpandedId(null);
      }
    } else {
      // iOS/Android confirmation
      Alert.alert("Delete Transaction", `Delete "${title}"?`, [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: () => {
            deleteTransaction(id);
            setExpandedId(null);
          },
        },
      ]);
    }
  };

  const handleEditOpen = (txn) => {
    setSelectedTxn(txn);
    setEditTitle(txn.title);
    setEditAmount(txn.amount.toString());
    setEditModal(true);
  };

  const handleEditSave = () => {
    if (!editTitle.trim() || !editAmount.trim()) {
      Alert.alert("Error", "Please fill in all fields");
      return;
    }
    editTransaction(selectedTxn.id, {
      title: editTitle,
      amount: parseFloat(editAmount),
    });
    setEditModal(false);
    Alert.alert("Success", "Transaction updated");
  };

  const renderItem = ({ item }) => {
    const categoryName = getCategoryName(item.category);
    const categoryIcon = getCategoryIcon(item.category);
    const isExpanded = expandedId === item.id;

    return (
      <View style={styles.txnItemWrapper}>
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => setExpandedId(isExpanded ? null : item.id)}
          style={styles.txnItem}
        >
          <View
            style={[
              styles.iconBox,
              {
                backgroundColor: item.type === "income" ? "#ECFDF3" : "#FEF3F2",
              },
            ]}
          >
            {categoryIcon ? (
              <Text style={styles.categoryEmoji}>{categoryIcon}</Text>
            ) : (
              <Ionicons
                name={item.type === "income" ? "arrow-down" : "cart-outline"}
                size={20}
                color={item.type === "income" ? "#027A48" : "#B42318"}
              />
            )}
          </View>
          <View style={{ flex: 1, marginLeft: 15 }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
              }}
            >
              <Text style={styles.txnTitle}>{item.title}</Text>
              <View style={styles.badge}>
                <Text style={styles.badgeText}>
                  {String(item.mode).toUpperCase()}
                </Text>
              </View>
            </View>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginTop: 4,
              }}
            >
              <Text style={styles.txnMeta}>{getRelativeTime(item.date)}</Text>
              {categoryName && (
                <View style={styles.categoryBadge}>
                  <Text style={styles.categoryBadgeText}>{categoryName}</Text>
                </View>
              )}
            </View>
          </View>
          <View style={styles.txnActions}>
            <Text
              style={[
                styles.txnAmt,
                { color: item.type === "income" ? "#027A48" : "#101828" },
              ]}
            >
              {item.type === "income" ? "+" : "-"} ₹{item.amount}
            </Text>
            <Ionicons
              name={isExpanded ? "chevron-up" : "chevron-down"}
              size={16}
              color="#667085"
              style={{ marginTop: 4 }}
            />
          </View>
        </TouchableOpacity>

        {/* Expandable Action Buttons */}
        {isExpanded && (
          <View style={styles.expandedActions}>
            <TouchableOpacity
              style={[styles.actionBtn, styles.editBtn]}
              onPress={() => {
                handleEditOpen(item);
                setExpandedId(null);
              }}
            >
              <Ionicons name="pencil" size={16} color="#FFF" />
              <Text style={styles.actionBtnText}>Edit</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.actionBtn, styles.deleteBtn]}
              onPress={() => handleDelete(item.id, item.title)}
            >
              <Ionicons name="trash" size={16} color="#FFF" />
              <Text style={styles.actionBtnText}>Delete</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Activity History</Text>

      {/* Search Bar */}
      <View style={styles.searchContainer}>
        <Ionicons name="search" size={18} color="#667085" />
        <TextInput
          placeholder="Search transactions..."
          style={styles.searchInput}
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
        <TouchableOpacity onPress={() => setShowFilters(!showFilters)}>
          <Ionicons name="funnel" size={18} color="#667085" />
        </TouchableOpacity>
      </View>

      {/* Filters */}
      {showFilters && (
        <View style={styles.filterContainer}>
          <Text style={styles.filterLabel}>Type:</Text>
          <View style={styles.filterButtons}>
            {["all", "income", "expense"].map((type) => (
              <TouchableOpacity
                key={type}
                style={[
                  styles.filterBtn,
                  filterType === type && styles.filterBtnActive,
                ]}
                onPress={() => setFilterType(type)}
              >
                <Text
                  style={[
                    styles.filterBtnText,
                    filterType === type && styles.filterBtnTextActive,
                  ]}
                >
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.filterLabel}>Category:</Text>
          <View style={styles.filterButtons}>
            <TouchableOpacity
              style={[
                styles.filterBtn,
                !filterCategory && styles.filterBtnActive,
              ]}
              onPress={() => setFilterCategory(null)}
            >
              <Text
                style={[
                  styles.filterBtnText,
                  !filterCategory && styles.filterBtnTextActive,
                ]}
              >
                All
              </Text>
            </TouchableOpacity>
            {categories.map((cat) => (
              <TouchableOpacity
                key={cat.id}
                style={[
                  styles.filterBtn,
                  filterCategory === cat.id && styles.filterBtnActive,
                ]}
                onPress={() => setFilterCategory(cat.id)}
              >
                <Text
                  style={[
                    styles.filterBtnText,
                    filterCategory === cat.id && styles.filterBtnTextActive,
                  ]}
                >
                  {cat.name}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={styles.filterLabel}>Mode:</Text>
          <View style={styles.filterButtons}>
            {["all", "online", "cash"].map((mode) => (
              <TouchableOpacity
                key={mode}
                style={[
                  styles.filterBtn,
                  filterMode === mode && styles.filterBtnActive,
                ]}
                onPress={() => setFilterMode(mode)}
              >
                <Text
                  style={[
                    styles.filterBtnText,
                    filterMode === mode && styles.filterBtnTextActive,
                  ]}
                >
                  {mode.charAt(0).toUpperCase() + mode.slice(1)}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {filteredTransactions.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="receipt-outline" size={50} color="#D0D5DD" />
          <Text style={styles.emptyText}>
            {searchQuery || filterType !== "all" || filterCategory
              ? "No matching transactions found."
              : "No transactions recorded yet."}
          </Text>
        </View>
      ) : (
        <FlatList
          data={[...filteredTransactions].reverse()}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingBottom: 100 }}
        />
      )}

      {/* Edit Transaction Modal */}
      <Modal visible={editModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Edit Transaction</Text>
            <TextInput
              placeholder="Transaction Title"
              style={styles.input}
              value={editTitle}
              onChangeText={setEditTitle}
            />
            <TextInput
              placeholder="Amount (₹)"
              style={styles.input}
              keyboardType="numeric"
              value={editAmount}
              onChangeText={setEditAmount}
            />
            <View style={{ flexDirection: "row", marginTop: 16 }}>
              <TouchableOpacity
                style={[styles.btn, { flex: 1, marginRight: 8 }]}
                onPress={handleEditSave}
              >
                <Text style={styles.btnText}>Save</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[
                  styles.btn,
                  { flex: 1, backgroundColor: "#EAECF0", marginLeft: 8 },
                ]}
                onPress={() => setEditModal(false)}
              >
                <Text style={[styles.btnText, { color: "#101828" }]}>
                  Cancel
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#FFF", padding: 20 },
  header: { fontSize: 24, fontWeight: "bold", marginTop: 40, marginBottom: 20 },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#F9FAFB",
    borderRadius: 10,
    paddingHorizontal: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#EAECF0",
  },
  searchInput: {
    flex: 1,
    paddingVertical: 12,
    marginLeft: 8,
    fontSize: 14,
    color: "#101828",
  },
  filterContainer: {
    backgroundColor: "#F9FAFB",
    padding: 12,
    borderRadius: 10,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#EAECF0",
  },
  filterLabel: {
    fontSize: 12,
    fontWeight: "600",
    color: "#667085",
    marginBottom: 8,
  },
  filterButtons: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginBottom: 12,
  },
  filterBtn: {
    backgroundColor: "#FFF",
    borderWidth: 1,
    borderColor: "#EAECF0",
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 6,
    marginRight: 8,
    marginBottom: 8,
  },
  filterBtnActive: {
    backgroundColor: "#101828",
    borderColor: "#101828",
  },
  filterBtnText: {
    fontSize: 12,
    color: "#667085",
    fontWeight: "500",
  },
  filterBtnTextActive: {
    color: "#FFF",
  },
  txnItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: "#F2F4F7",
  },
  iconBox: {
    width: 45,
    height: 45,
    borderRadius: 12,
    justifyContent: "center",
    alignItems: "center",
  },
  txnTitle: { fontSize: 16, fontWeight: "600", color: "#101828" },
  txnMeta: { fontSize: 12, color: "#667085" },
  txnAmt: { fontSize: 16, fontWeight: "bold" },
  badge: {
    backgroundColor: "#F3F4F6",
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 8,
  },
  badgeText: { fontSize: 10, fontWeight: "700", color: "#101828" },
  categoryBadge: {
    backgroundColor: "#E0E7FF",
    paddingVertical: 4,
    paddingHorizontal: 8,
    borderRadius: 6,
    marginLeft: 8,
  },
  categoryBadgeText: { fontSize: 10, color: "#4F46E5", fontWeight: "600" },
  categoryEmoji: { fontSize: 20 },
  txnActions: { flexDirection: "column", alignItems: "flex-end" },
  actionButtons: { flexDirection: "row", marginTop: 4 },
  iconBtn: { paddingHorizontal: 6, paddingVertical: 4 },
  txnItemWrapper: {
    marginBottom: 2,
  },
  expandedActions: {
    flexDirection: "row",
    backgroundColor: "#F9FAFB",
    borderTopWidth: 1,
    borderTopColor: "#F2F4F7",
    borderBottomWidth: 1,
    borderBottomColor: "#F2F4F7",
    paddingVertical: 8,
    paddingHorizontal: 15,
    gap: 8,
  },
  actionBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 8,
    gap: 6,
  },
  editBtn: {
    backgroundColor: "#2E90FA",
  },
  deleteBtn: {
    backgroundColor: "#EF4444",
  },
  actionBtnText: {
    color: "#FFF",
    fontWeight: "600",
    fontSize: 12,
  },
  emptyState: { flex: 1, justifyContent: "center", alignItems: "center" },
  emptyText: { color: "#98A2B3", marginTop: 10 },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    padding: 20,
  },
  modalContent: {
    backgroundColor: "white",
    padding: 25,
    borderRadius: 16,
    elevation: 5,
  },
  modalTitle: { fontSize: 18, fontWeight: "bold", marginBottom: 16 },
  input: {
    backgroundColor: "#F9FAFB",
    padding: 12,
    borderRadius: 10,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#EAECF0",
  },
  btn: {
    backgroundColor: "#101828",
    padding: 12,
    borderRadius: 10,
    alignItems: "center",
  },
  btnText: { color: "#fff", fontWeight: "bold", fontSize: 14 },
});
