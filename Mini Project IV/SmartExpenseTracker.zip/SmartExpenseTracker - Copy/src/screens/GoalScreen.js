import { Ionicons } from "@expo/vector-icons";
import { useContext } from "react";
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { AppContext } from "../context/AppContext";

export default function GoalScreen() {
  const {
    manualGoal,
    setManualGoal,
    manualSaved,
    setManualSaved,
    dailyBaseline,
    setDailyBaseline,
    saveGoalToCloud,
  } = useContext(AppContext);

  // Handle Save Goal with alert feedback
  const handleSaveGoal = () => {
    console.log("💾 Saving goal...");
    saveGoalToCloud(manualGoal, manualSaved, dailyBaseline);
    Alert.alert(
      "✅ Goal Saved",
      `Target: ₹${manualGoal}\nAlready Saved: ₹${manualSaved}\nDaily Baseline: ₹${dailyBaseline}`,
      [{ text: "OK", onPress: () => console.log("Alert dismissed") }],
    );
  };

  // PPT Logic: Goal Date Shifter calculation
  const remainingAmount = manualGoal - manualSaved;
  const daysToReachGoal =
    remainingAmount > 0 && dailyBaseline > 0
      ? Math.ceil(remainingAmount / dailyBaseline)
      : 0;

  // Formatting date for the "Goal Date Shifter"
  const getGoalDate = () => {
    let date = new Date();
    date.setDate(date.getDate() + daysToReachGoal);
    return date.toLocaleDateString("en-IN", {
      day: "numeric",
      month: "short",
      year: "numeric",
    });
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.header}>Savings Goal</Text>
        <Text style={styles.subHeader}>
          Manually define your path to financial freedom
        </Text>

        {/* Target Card */}
        <View style={styles.card}>
          <View style={styles.row}>
            <Ionicons name="trophy-outline" size={24} color="#F79009" />
            <Text style={styles.cardTitle}>Financial Target</Text>
          </View>
          <View style={styles.inputWrapper}>
            <Text style={styles.currency}>₹</Text>
            <TextInput
              style={styles.mainInput}
              keyboardType="numeric"
              value={manualGoal.toString()}
              onChangeText={(v) => {
                const newGoal = parseFloat(v) || 0;
                setManualGoal(newGoal);
                saveGoalToCloud(newGoal, manualSaved, dailyBaseline);
              }}
              placeholder="0"
            />
          </View>
          <Text style={styles.inputHint}>Total amount you want to save</Text>
        </View>

        {/* Current Progress Card */}
        <View style={styles.card}>
          <View style={styles.row}>
            <Ionicons name="wallet-outline" size={24} color="#2E90FA" />
            <Text style={styles.cardTitle}>Already Saved</Text>
          </View>
          <View style={styles.inputWrapper}>
            <Text style={styles.currency}>₹</Text>
            <TextInput
              style={[styles.mainInput, { color: "#2E90FA" }]}
              keyboardType="numeric"
              value={manualSaved.toString()}
              onChangeText={(v) => {
                const newSaved = parseFloat(v) || 0;
                setManualSaved(newSaved);
                saveGoalToCloud(manualGoal, newSaved, dailyBaseline);
              }}
              placeholder="0"
            />
          </View>
          <Text style={styles.inputHint}>
            Funds currently set aside for this goal
          </Text>
        </View>

        {/* Daily Baseline Card */}
        <View style={styles.card}>
          <View style={styles.row}>
            <Ionicons name="trending-up-outline" size={24} color="#12B76A" />
            <Text style={styles.cardTitle}>Daily Savings Baseline</Text>
          </View>
          <View style={styles.inputWrapper}>
            <Text style={styles.currency}>₹</Text>
            <TextInput
              style={[styles.mainInput, { color: "#12B76A" }]}
              keyboardType="numeric"
              value={dailyBaseline.toString()}
              onChangeText={(v) => {
                const newBaseline = parseFloat(v) || 0;
                setDailyBaseline(newBaseline);
                saveGoalToCloud(manualGoal, manualSaved, newBaseline);
              }}
              placeholder="0"
            />
          </View>
          <Text style={styles.inputHint}>
            How much you can realistically save per day
          </Text>
        </View>

        {/* Goal Date Shifter Output */}
        <View style={styles.shifterCard}>
          <Text style={styles.shifterLabel}>GOAL DATE SHIFTER</Text>
          <Text style={styles.shifterDate}>{getGoalDate()}</Text>
          <View style={styles.divider} />
          <View style={styles.row}>
            <Ionicons name="time-outline" size={18} color="#fff" />
            <Text style={styles.shifterDays}>
              {daysToReachGoal} Days remaining
            </Text>
          </View>
          <Text style={styles.shifterNote}>
            *Adjust your daily baseline to see the date shift dynamically.
          </Text>
        </View>
        <TouchableOpacity style={styles.saveButton} onPress={handleSaveGoal}>
          <Text style={{ color: "#fff", fontWeight: "bold", fontSize: 16 }}>
            Save Goal
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  scrollContent: { padding: 25, paddingBottom: 50 },
  header: { fontSize: 28, fontWeight: "bold", color: "#101828", marginTop: 40 },
  subHeader: { fontSize: 14, color: "#667085", marginBottom: 25 },
  card: {
    backgroundColor: "#F9FAFB",
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: "#EAECF0",
  },
  row: { flexDirection: "row", alignItems: "center", marginBottom: 10 },
  cardTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#344054",
    marginLeft: 10,
  },
  inputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 5,
  },
  currency: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#101828",
    marginRight: 5,
  },
  mainInput: { fontSize: 32, fontWeight: "bold", color: "#101828", flex: 1 },
  inputHint: { fontSize: 12, color: "#98A2B3" },
  shifterCard: {
    backgroundColor: "#101828",
    borderRadius: 24,
    padding: 25,
    marginTop: 10,
    elevation: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  shifterLabel: {
    color: "#F79009",
    fontWeight: "bold",
    letterSpacing: 1.5,
    fontSize: 12,
  },
  shifterDate: {
    color: "#fff",
    fontSize: 32,
    fontWeight: "bold",
    marginVertical: 10,
  },
  divider: {
    height: 1,
    backgroundColor: "rgba(255,255,255,0.1)",
    marginVertical: 15,
  },
  shifterDays: { color: "#fff", fontSize: 16, marginLeft: 8 },
  shifterNote: {
    color: "#98A2B3",
    fontSize: 11,
    marginTop: 15,
    fontStyle: "italic",
  },
  saveButton: {
    backgroundColor: "#667EEA",
    padding: 15,
    borderRadius: 18,
    alignItems: "center",
    marginTop: 20,
  },
});
