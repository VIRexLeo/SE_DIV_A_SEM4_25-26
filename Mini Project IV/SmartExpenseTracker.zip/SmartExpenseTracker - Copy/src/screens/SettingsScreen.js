import { Ionicons } from "@expo/vector-icons";
import { ref, set } from "firebase/database";
import { useContext, useState } from "react";
import {
    Alert,
    BackHandler,
    Modal,
    Platform,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from "react-native";
import { auth, db } from "../../firebase";
import { AppContext } from "../context/AppContext";

export default function SettingsScreen({ navigation }) {
  const {
    notificationSettings,
    setNotificationSettings,
    setOnlineBudget,
    setCashBudget,
  } = useContext(AppContext);
  const [aboutModal, setAboutModal] = useState(false);
  const [budgetModal, setBudgetModal] = useState(false);
  const [notifModal, setNotifModal] = useState(false);
  const [onlineBudgetInput, setOnlineBudgetInput] = useState("");
  const [cashBudgetInput, setCashBudgetInput] = useState("");

  // ✅ NEW: Proper exit handler for both web and mobile
  const handleExit = () => {
    if (Platform.OS === "web") {
      // For web: Show confirmation and close window
      if (window.confirm("Are you sure you want to close the app?")) {
        window.close();
      }
    } else {
      // For mobile (iOS/Android): Use BackHandler to exit gracefully
      Alert.alert(
        "Exit App",
        "Are you sure you want to exit the app?",
        [
          { text: "Cancel", onPress: () => {}, style: "cancel" },
          {
            text: "Exit",
            onPress: () => {
              BackHandler.exitApp();
            },
            style: "destructive",
          },
        ]
      );
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: "#FFFFFF" }]}>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: "#FFFFFF" }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={28} color="#101828" />
        </TouchableOpacity>
        <Text style={[styles.headerTitle, { color: "#101828" }]}>Settings</Text>
        <View style={{ width: 28 }} />
      </View>
      {/* Main content */}
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 40 }}
      >
        <View style={styles.optionList}>
          <TouchableOpacity
            style={styles.option}
            onPress={() => setBudgetModal(true)}
          >
            <Text style={[styles.optionText, { color: "#101828" }]}>
              Initialize Monthly Budget
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.option}
            onPress={() => setNotifModal(true)}
          >
            <Text style={[styles.optionText, { color: "#101828" }]}>
              Notification Preferences
            </Text>
          </TouchableOpacity>
          {/* Static Mode Info (no toggle) */}
          <View
            style={[
              styles.option,
              {
                flexDirection: "row",
                justifyContent: "space-between",
                alignItems: "center",
              },
            ]}
          >
            <Text style={[styles.optionText, { color: "#ffffff" }]}>
              Dark Mode
            </Text>
            <Text style={{ color: "#ffffff" }}>Static mode enabled</Text>
          </View>
          <TouchableOpacity
            style={styles.option}
            onPress={() => setAboutModal(true)}
          >
            <Text style={[styles.optionText, { color: "#fafbff" }]}>
              About App
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.option}
            onPress={() => navigation.navigate("Debug")}
          >
            <Text style={[styles.optionText, { color: "#101828" }]}>
              Debug Console
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.option} onPress={handleExit}>
            <Text style={[styles.optionText, { color: "#101828" }]}>
              Exit App
            </Text>
          </TouchableOpacity>
        </View>
        {/* About Modal */}
        <Modal visible={aboutModal} transparent animationType="fade">
          <View style={styles.modalBackdrop}>
            <View style={[styles.modalContent, { backgroundColor: "#FFFFFF" }]}>
              <Text style={[styles.modalTitle, { color: "#101828" }]}>
                About SmartExpenseTracker
              </Text>
              <Text style={{ color: "#667085", marginTop: 10 }}>
                This app helps you track balances, categories and savings goals.
              </Text>
              <TouchableOpacity
                style={[styles.btn, { marginTop: 12 }]}
                onPress={() => setAboutModal(false)}
              >
                <Text style={{ color: "#fff", fontWeight: "bold" }}>Close</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
        {/* Initialize Monthly Budget Modal */}
        <Modal visible={budgetModal} transparent animationType="slide">
          <View style={styles.modalBackdrop}>
            <View style={[styles.modalContent, { backgroundColor: "#FFFFFF" }]}>
              <Text style={[styles.modalTitle, { color: "#101828" }]}>
                Initialize Monthly Budget
              </Text>
              <Text
                style={{ color: "#667085", marginTop: 8, marginBottom: 16 }}
              >
                Set your starting balance for this month
              </Text>
              <TextInput
                placeholder="Online Starting Budget (₹)"
                placeholderTextColor="#9CA3AF"
                style={[styles.input, { color: "#101828" }]}
                keyboardType="numeric"
                value={onlineBudgetInput}
                onChangeText={setOnlineBudgetInput}
              />
              <TextInput
                placeholder="Cash Starting Budget (₹)"
                placeholderTextColor="#9CA3AF"
                style={[styles.input, { color: "#101828" }]}
                keyboardType="numeric"
                value={cashBudgetInput}
                onChangeText={setCashBudgetInput}
              />
              <View style={{ flexDirection: "row", marginTop: 16 }}>
                <TouchableOpacity
                  style={[styles.btn, { flex: 1 }]}
                  onPress={() => {
                    if (!onlineBudgetInput || !cashBudgetInput) {
                      Alert.alert("Incomplete", "Please enter both budgets.");
                      return;
                    }
                    const onlineVal = parseFloat(onlineBudgetInput);
                    const cashVal = parseFloat(cashBudgetInput);
                    setOnlineBudget(onlineVal);
                    setCashBudget(cashVal);
                    const user = auth.currentUser;
                    if (user) {
                      set(ref(db, `budgets/${user.uid}`), {
                        onlineBudget: onlineVal,
                        cashBudget: cashVal,
                      });
                    }
                    setBudgetModal(false);
                  }}
                >
                  <Text style={{ color: "#fff", fontWeight: "bold" }}>
                    Initialize
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.btn,
                    { flex: 1, backgroundColor: "#EAECF0", marginLeft: 8 },
                  ]}
                  onPress={() => setBudgetModal(false)}
                >
                  <Text style={{ color: "#101828", fontWeight: "bold" }}>
                    Cancel
                  </Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
        {/* Notification Preferences Modal */}
        <Modal visible={notifModal} transparent animationType="slide">
          <View style={styles.modalBackdrop}>
            <View style={[styles.modalContent, { backgroundColor: "#FFFFFF" }]}>
              <Text style={[styles.modalTitle, { color: "#101828" }]}>
                Notification Preferences
              </Text>
              <View style={styles.notificationItem}>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.notifTitle, { color: "#101828" }]}>
                    Budget Alerts
                  </Text>
                  <Text style={{ color: "#667085", fontSize: 13 }}>
                    Notify on thresholds
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={() =>
                    setNotificationSettings({
                      ...notificationSettings,
                      budgetAlerts: !notificationSettings.budgetAlerts,
                    })
                  }
                  style={[
                    styles.toggle,
                    notificationSettings.budgetAlerts && styles.toggleActive,
                  ]}
                >
                  {notificationSettings.budgetAlerts && (
                    <View style={styles.toggleDot} />
                  )}
                </TouchableOpacity>
              </View>
              <TouchableOpacity
                style={[styles.btn, { marginTop: 20 }]}
                onPress={() => setNotifModal(false)}
              >
                <Text style={{ color: "#fff", fontWeight: "bold" }}>Done</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingTop: 50,
    paddingBottom: 24,
  },
  headerTitle: { fontSize: 24, fontWeight: "900" },
  optionList: { marginHorizontal: 20 },
  option: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "#F3F4F6",
  },
  optionText: { fontSize: 16, fontWeight: "600" },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.4)",
    justifyContent: "center",
    padding: 20,
  },
  modalContent: {
    padding: 24,
    borderRadius: 20,
    elevation: 8,
  },
  modalTitle: { fontSize: 20, fontWeight: "800" },
  input: {
    backgroundColor: "#F8F9FF",
    padding: 14,
    borderRadius: 12,
    marginTop: 14,
    borderWidth: 1.5,
    borderColor: "#E5E7EB",
    fontSize: 16,
  },
  btn: {
    backgroundColor: "#667EEA",
    padding: 14,
    borderRadius: 12,
    alignItems: "center",
  },
  notificationItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 14,
  },
  notifTitle: { fontSize: 15, fontWeight: "700" },
  toggle: {
    width: 50,
    height: 28,
    borderRadius: 14,
    backgroundColor: "#E5E7EB",
    justifyContent: "center",
    paddingHorizontal: 2,
  },
  toggleActive: { backgroundColor: "#667EEA", alignItems: "flex-end" },
  toggleDot: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: "#fff",
  },
});
