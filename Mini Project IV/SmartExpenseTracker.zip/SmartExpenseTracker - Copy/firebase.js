import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getDatabase } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyCDOueI1llHOHEpDTRw-TrFs-a5Yr7az2s",
  authDomain: "expense-tracker-d078b.firebaseapp.com",
  databaseURL: "https://expense-tracker-d078b-default-rtdb.firebaseio.com/",
  projectId: "expense-tracker-d078b",
  storageBucket: "expense-tracker-d078b.firebasestorage.app",
  messagingSenderId: "722739386985",
  appId: "1:722739386985:web:7f633ceafa62615635e0f8",
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getDatabase(app); // 👈 Realtime DB
