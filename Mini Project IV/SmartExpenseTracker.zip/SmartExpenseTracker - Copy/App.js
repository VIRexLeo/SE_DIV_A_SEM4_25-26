import { Ionicons } from "@expo/vector-icons";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { useContext } from "react";
import { AppContext, AppProvider } from "./src/context/AppContext";

import CategoryInsightsScreen from "./src/screens/CategoryInsightsScreen";
import CategoryScreen from "./src/screens/CategoryScreen";
import DebugContextScreen from "./src/screens/DebugContextScreen.js";
import GoalScreen from "./src/screens/GoalScreen";
import HistoryScreen from "./src/screens/HistoryScreen";
import HomeScreen from "./src/screens/HomeScreen";
import LoginScreen from "./src/screens/LoginScreen";
import ProfileScreen from "./src/screens/ProfileScreen";
import SettingsScreen from "./src/screens/SettingsScreen";



const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let icon = {
            Home: "home",
            Goal: "trophy",
            History: "time",
            Category: "grid",
          }[route.name];
          return <Ionicons name={icon} size={size} color={color} />;
        },
        tabBarActiveTintColor: "#101828",
        headerShown: false,
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Goal" component={GoalScreen} />
      <Tab.Screen name="History" component={HistoryScreen} />
      <Tab.Screen name="Category" component={CategoryScreen} />
    </Tab.Navigator>
  );
}

function AuthStack() {
  const { isAuth, setIsAuth } = useContext(AppContext);
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {!isAuth ? (
        <Stack.Screen name="Login">
          {(props) => (
            <LoginScreen {...props} onLogin={() => setIsAuth(true)} />
          )}
        </Stack.Screen>
      ) : (
        <>
          <Stack.Screen name="Main" component={MainTabs} />
          <Stack.Screen
            name="Settings"
            component={SettingsScreen}
            options={{ headerShown: true }}
          />
          <Stack.Screen
            name="CategoryInsights"
            component={CategoryInsightsScreen}
            options={{ headerShown: true, title: "Category Insights" }}
          />
          <Stack.Screen
            name="Debug"
            component={DebugContextScreen}
            options={{ headerShown: true }}
          />
          <Stack.Screen name="Profile" component={ProfileScreen} />
        </>
      )}
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <AppProvider>
      <NavigationContainer>
        <AuthStack />
      </NavigationContainer>
    </AppProvider>
  );
}
